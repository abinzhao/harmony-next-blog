# Node.js 管理服务器

一个功能齐全的 Node.js 管理服务器，包含用户管理、文章管理、应用管理和系统公告功能。

## 功能特点

- **用户管理**：注册、登录、修改密码、修改信息、查询、删除、停用账号
- **文章管理**：创建、更新、删除、查询文章和帖子
- **应用管理**：上传应用（HAP 安装包）、应用截图管理、应用更新和迭代
- **系统公告**：创建、更新、删除、查询系统公告

## 技术栈

- Node.js + Express
- MongoDB (Mongoose)
- JWT 身份验证
- Multer 文件上传

## 安装与运行

1. 克隆仓库
2. 安装依赖：`npm install`
3. 配置环境变量：复制 `.env.example` 到 `.env` 并填写配置
4. 启动服务器：`npm run dev`

## API 文档

### 用户管理

- `POST /api/users/register` - 注册新用户
- `POST /api/users/login` - 用户登录
- `GET /api/users/me` - 获取当前用户信息
- `PUT /api/users/me` - 更新用户信息
- `PUT /api/users/updatepassword` - 更新密码
- `GET /api/users` - 获取所有用户 (管理员)
- `GET /api/users/:id` - 获取单个用户 (管理员)
- `PUT /api/users/:id` - 更新用户 (管理员)
- `DELETE /api/users/:id` - 删除用户 (管理员)
- `PUT /api/users/:id/deactivate` - 停用用户账号 (管理员)

### 文章管理

- `POST /api/articles` - 创建文章
- `GET /api/articles` - 获取所有文章
- `GET /api/articles/:id` - 获取单个文章
- `PUT /api/articles/:id` - 更新文章
- `DELETE /api/articles/:id` - 删除文章
- `PUT /api/articles/:id/like` - 点赞文章

### 应用管理

- `POST /api/apps` - 上传应用
- `GET /api/apps` - 获取所有应用
- `GET /api/apps/:id` - 获取单个应用
- `PUT /api/apps/:id` - 更新应用信息
- `DELETE /api/apps/:id` - 删除应用
- `GET /api/apps/:id/download` - 下载应用

### 系统公告

- `POST /api/announcements` - 创建公告 (管理员)
- `GET /api/announcements` - 获取所有公告
- `GET /api/announcements/:id` - 获取单个公告
- `PUT /api/announcements/:id` - 更新公告 (管理员)
- `DELETE /api/announcements/:id` - 删除公告 (管理员)
- `PUT /api/announcements/:id/toggle` - 激活/停用公告 (管理员)
