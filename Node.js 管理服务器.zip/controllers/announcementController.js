const Announcement = require('../models/Announcement');
const { validationResult } = require('express-validator');

// @desc    创建公告
// @route   POST /api/announcements
// @access  Private/Admin
exports.createAnnouncement = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    // 添加创建者信息
    req.body.createdBy = req.user.id;
    
    const announcement = await Announcement.create(req.body);
    
    res.status(201).json({
      success: true,
      data: announcement
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    获取所有公告
// @route   GET /api/announcements
// @access  Public
exports.getAnnouncements = async (req, res) => {
  try {
    // 构建查询
    const query = {};
    
    // 默认只获取活跃的公告
    if (req.query.all !== 'true') {
      query.isActive = true;
      
      // 检查日期范围
      const now = new Date();
      query.startDate = { $lte: now };
      query.$or = [
        { endDate: { $exists: false } },
        { endDate: null },
        { endDate: { $gte: now } }
      ];
    }
    
    // 根据优先级筛选
    if (req.query.priority) {
      query.priority = req.query.priority;
    }
    
    // 分页
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    
    const announcements = await Announcement.find(query)
      .populate({
        path: 'createdBy',
        select: 'username'
      })
      .sort({ priority: -1, createdAt: -1 })
      .skip(startIndex)
      .limit(limit);
      
    const total = await Announcement.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: announcements.length,
      total,
      pagination: {
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      data: announcements
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    获取单个公告
// @route   GET /api/announcements/:id
// @access  Public
exports.getAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id).populate({
      path: 'createdBy',
      select: 'username'
    });
    
    if (!announcement) {
      return res.status(404).json({
        success: false,
        error: '找不到公告'
      });
    }
    
    res.status(200).json({
      success: true,
      data: announcement
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    更新公告
// @route   PUT /api/announcements/:id
// @access  Private/Admin
exports.updateAnnouncement = async (req, res) => {
  try {
    let announcement = await Announcement.findById(req.params.id);
    
    if (!announcement) {
      return res.status(404).json({
        success: false,
        error: '找不到公告'
      });
    }
    
    // 更新时间
    req.body.updatedAt = Date.now();
    
    announcement = await Announcement.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    
    res.status(200).json({
      success: true,
      data: announcement
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    删除公告
// @route   DELETE /api/announcements/:id
// @access  Private/Admin
exports.deleteAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id);
    
    if (!announcement) {
      return res.status(404).json({
        success: false,
        error: '找不到公告'
      });
    }
    
    await announcement.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    激活/停用公告
// @route   PUT /api/announcements/:id/toggle
// @access  Private/Admin
exports.toggleAnnouncement = async (req, res) => {
  try {
    const announcement = await Announcement.findById(req.params.id);
    
    if (!announcement) {
      return res.status(404).json({
        success: false,
        error: '找不到公告'
      });
    }
    
    announcement.isActive = !announcement.isActive;
    announcement.updatedAt = Date.now();
    await announcement.save();
    
    res.status(200).json({
      success: true,
      data: announcement
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};
