const App = require('../models/App');
const { validationResult } = require('express-validator');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');

// 设置存储
const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    // 根据应用包名创建目录
    const packageName = req.body.packageName;
    const appDir = path.join(__dirname, '../uploads/apps', packageName);
    
    // 确保目录存在
    fs.ensureDirSync(appDir);
    
    cb(null, appDir);
  },
  filename: function(req, file, cb) {
    // 根据文件类型设置文件名
    if (file.fieldname === 'installPackage') {
      cb(null, `${req.body.packageName}_${req.body.version}.hap`);
    } else if (file.fieldname === 'screenshots') {
      cb(null, `screenshot_${Date.now()}${path.extname(file.originalname)}`);
    } else {
      cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
    }
  }
});

// 文件上传中间件
const upload = multer({
  storage: storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB 限制
  fileFilter: function(req, file, cb) {
    if (file.fieldname === 'installPackage') {
      // 仅允许 .hap 文件
      if (path.extname(file.originalname) !== '.hap') {
        return cb(new Error('仅允许上传 .hap 文件'), false);
      }
    } else if (file.fieldname === 'screenshots') {
      // 仅允许图片文件
      const filetypes = /jpeg|jpg|png|gif/;
      const mimetype = filetypes.test(file.mimetype);
      const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
      
      if (!mimetype || !extname) {
        return cb(new Error('仅允许上传图片文件'), false);
      }
    }
    cb(null, true);
  }
}).fields([
  { name: 'installPackage', maxCount: 1 },
  { name: 'screenshots', maxCount: 5 }
]);

// @desc    上传应用
// @route   POST /api/apps
// @access  Private
exports.uploadApp = async (req, res) => {
  try {
    // 处理文件上传
    upload(req, res, async function(err) {
      if (err) {
        return res.status(400).json({
          success: false,
          error: err.message
        });
      }
      
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }
      
      const { packageName, name, version, description, category } = req.body;
      
      try {
        // 检查是否有安装包
        if (!req.files.installPackage) {
          return res.status(400).json({
            success: false,
            error: '请上传安装包'
          });
        }
        
        // 检查应用是否已存在
        let app = await App.findOne({ packageName });
        
        if (app) {
          // 更新现有应用
          app.name = name;
          app.version = version;
          app.description = description;
          app.category = category;
          app.installPackage = `/uploads/apps/${packageName}/${packageName}_${version}.hap`;
          app.updatedAt = Date.now();
          
          // 添加新的截图
          if (req.files.screenshots) {
            const newScreenshots = req.files.screenshots.map(
              file => `/uploads/apps/${packageName}/${file.filename}`
            );
            app.screenshots = newScreenshots;
          }
          
          await app.save();
          
          return res.status(200).json({
            success: true,
            data: app
          });
        } else {
          // 创建新应用
          const installPackagePath = `/uploads/apps/${packageName}/${packageName}_${version}.hap`;
          
          const screenshots = req.files.screenshots
            ? req.files.screenshots.map(
                file => `/uploads/apps/${packageName}/${file.filename}`
              )
            : [];
          
          app = await App.create({
            name,
            packageName,
            version,
            description,
            category,
            installPackage: installPackagePath,
            screenshots,
            developer: req.user.id
          });
          
          return res.status(201).json({
            success: true,
            data: app
          });
        }
      } catch (err) {
        return res.status(500).json({
          success: false,
          error: err.message
        });
      }
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    获取所有应用
// @route   GET /api/apps
// @access  Public
exports.getApps = async (req, res) => {
  try {
    // 构建查询
    const query = {};
    
    // 根据分类筛选
    if (req.query.category) {
      query.category = req.query.category;
    }
    
    // 搜索
    if (req.query.search) {
      query.$or = [
        { name: { $regex: req.query.search, $options: 'i' } },
        { description: { $regex: req.query.search, $options: 'i' } }
      ];
    }
    
    // 分页
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    
    const apps = await App.find(query)
      .populate({
        path: 'developer',
        select: 'username'
      })
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit);
      
    const total = await App.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: apps.length,
      total,
      pagination: {
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      data: apps
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    获取单个应用
// @route   GET /api/apps/:id
// @access  Public
exports.getApp = async (req, res) => {
  try {
    const app = await App.findById(req.params.id).populate({
      path: 'developer',
      select: 'username'
    });
    
    if (!app) {
      return res.status(404).json({
        success: false,
        error: '找不到应用'
      });
    }
    
    res.status(200).json({
      success: true,
      data: app
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    更新应用信息（不包括文件）
// @route   PUT /api/apps/:id
// @access  Private
exports.updateApp = async (req, res) => {
  try {
    let app = await App.findById(req.params.id);
    
    if (!app) {
      return res.status(404).json({
        success: false,
        error: '找不到应用'
      });
    }
    
    // 确保用户是应用开发者或管理员
    if (app.developer.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '没有权限更新此应用'
      });
    }
    
    // 不允许修改包名
    delete req.body.packageName;
    
    // 更新时间
    req.body.updatedAt = Date.now();
    
    app = await App.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    
    res.status(200).json({
      success: true,
      data: app
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    删除应用
// @route   DELETE /api/apps/:id
// @access  Private
exports.deleteApp = async (req, res) => {
  try {
    const app = await App.findById(req.params.id);
    
    if (!app) {
      return res.status(404).json({
        success: false,
        error: '找不到应用'
      });
    }
    
    // 确保用户是应用开发者或管理员
    if (app.developer.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '没有权限删除此应用'
      });
    }
    
    // 删除应用目录
    const appDir = path.join(__dirname, '../uploads/apps', app.packageName);
    await fs.remove(appDir);
    
    // 删除数据库记录
    await app.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    下载应用
// @route   GET /api/apps/:id/download
// @access  Public
exports.downloadApp = async (req, res) => {
  try {
    const app = await App.findById(req.params.id);
    
    if (!app) {
      return res.status(404).json({
        success: false,
        error: '找不到应用'
      });
    }
    
    // 增加下载次数
    app.downloads += 1;
    await app.save();
    
    // 返回下载链接
    res.status(200).json({
      success: true,
      data: {
        downloadUrl: app.installPackage
      }
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};
