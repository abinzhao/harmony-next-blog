const Article = require('../models/Article');
const { validationResult } = require('express-validator');

// @desc    创建文章
// @route   POST /api/articles
// @access  Private
exports.createArticle = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    // 添加作者信息
    req.body.author = req.user.id;
    
    const article = await Article.create(req.body);
    
    res.status(201).json({
      success: true,
      data: article
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    获取所有文章
// @route   GET /api/articles
// @access  Public
exports.getArticles = async (req, res) => {
  try {
    // 构建查询
    const query = {};
    
    // 根据类型筛选
    if (req.query.type) {
      query.type = req.query.type;
    }
    
    // 根据标签筛选
    if (req.query.tag) {
      query.tags = { $in: [req.query.tag] };
    }
    
    // 全文搜索
    if (req.query.search) {
      query.$text = { $search: req.query.search };
    }
    
    // 分页
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    
    const articles = await Article.find(query)
      .populate({
        path: 'author',
        select: 'username'
      })
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit);
      
    const total = await Article.countDocuments(query);
    
    res.status(200).json({
      success: true,
      count: articles.length,
      total,
      pagination: {
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      },
      data: articles
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    获取单个文章
// @route   GET /api/articles/:id
// @access  Public
exports.getArticle = async (req, res) => {
  try {
    const article = await Article.findById(req.params.id).populate({
      path: 'author',
      select: 'username'
    });
    
    if (!article) {
      return res.status(404).json({
        success: false,
        error: '找不到文章'
      });
    }
    
    // 增加浏览次数
    article.views += 1;
    await article.save();
    
    res.status(200).json({
      success: true,
      data: article
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    更新文章
// @route   PUT /api/articles/:id
// @access  Private
exports.updateArticle = async (req, res) => {
  try {
    let article = await Article.findById(req.params.id);
    
    if (!article) {
      return res.status(404).json({
        success: false,
        error: '找不到文章'
      });
    }
    
    // 确保用户是文章作者或管理员
    if (article.author.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '没有权限更新此文章'
      });
    }
    
    // 更新时间
    req.body.updatedAt = Date.now();
    
    article = await Article.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });
    
    res.status(200).json({
      success: true,
      data: article
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    删除文章
// @route   DELETE /api/articles/:id
// @access  Private
exports.deleteArticle = async (req, res) => {
  try {
    const article = await Article.findById(req.params.id);
    
    if (!article) {
      return res.status(404).json({
        success: false,
        error: '找不到文章'
      });
    }
    
    // 确保用户是文章作者或管理员
    if (article.author.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '没有权限删除此文章'
      });
    }
    
    await article.deleteOne();
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};

// @desc    点赞文章
// @route   PUT /api/articles/:id/like
// @access  Private
exports.likeArticle = async (req, res) => {
  try {
    const article = await Article.findById(req.params.id);
    
    if (!article) {
      return res.status(404).json({
        success: false,
        error: '找不到文章'
      });
    }
    
    article.likes += 1;
    await article.save();
    
    res.status(200).json({
      success: true,
      data: article
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message
    });
  }
};
