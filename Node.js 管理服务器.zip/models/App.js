const mongoose = require('mongoose');

const AppSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, '请提供应用名称'],
    trim: true
  },
  packageName: {
    type: String,
    required: [true, '请提供应用包名'],
    unique: true,
    trim: true
  },
  version: {
    type: String,
    required: [true, '请提供版本号']
  },
  description: {
    type: String,
    required: [true, '请提供应用描述']
  },
  category: {
    type: String,
    required: [true, '请提供应用分类']
  },
  installPackage: {
    type: String,
    required: [true, '请提供安装包路径']
  },
  screenshots: [String],
  downloads: {
    type: Number,
    default: 0
  },
  developer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('App', AppSchema);
