const express = require('express');
const { check } = require('express-validator');
const {
  createAnnouncement,
  getAnnouncements,
  getAnnouncement,
  updateAnnouncement,
  deleteAnnouncement,
  toggleAnnouncement
} = require('../controllers/announcementController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// 公开路由
router.get('/', getAnnouncements);
router.get('/:id', getAnnouncement);

// 管理员路由
router.post(
  '/',
  [
    protect,
    authorize('admin'),
    [
      check('title', '公告标题是必需的').not().isEmpty(),
      check('content', '公告内容是必需的').not().isEmpty(),
      check('priority', '优先级必须是 low、normal、high 或 urgent').isIn(['low', 'normal', 'high', 'urgent'])
    ]
  ],
  createAnnouncement
);
router.put('/:id', protect, authorize('admin'), updateAnnouncement);
router.delete('/:id', protect, authorize('admin'), deleteAnnouncement);
router.put('/:id/toggle', protect, authorize('admin'), toggleAnnouncement);

module.exports = router;
