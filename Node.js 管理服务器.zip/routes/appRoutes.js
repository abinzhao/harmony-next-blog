const express = require('express');
const { check } = require('express-validator');
const {
  uploadApp,
  getApps,
  getApp,
  updateApp,
  deleteApp,
  downloadApp
} = require('../controllers/appController');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 公开路由
router.get('/', getApps);
router.get('/:id', getApp);
router.get('/:id/download', downloadApp);

// 受保护的路由
router.post(
  '/',
  [
    protect,
    [
      check('name', '应用名称是必需的').not().isEmpty(),
      check('packageName', '应用包名是必需的').not().isEmpty(),
      check('version', '版本号是必需的').not().isEmpty(),
      check('description', '应用描述是必需的').not().isEmpty(),
      check('category', '应用分类是必需的').not().isEmpty()
    ]
  ],
  uploadApp
);
router.put('/:id', protect, updateApp);
router.delete('/:id', protect, deleteApp);

module.exports = router;
