const express = require('express');
const { check } = require('express-validator');
const {
  createArticle,
  getArticles,
  getArticle,
  updateArticle,
  deleteArticle,
  likeArticle
} = require('../controllers/articleController');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 公开路由
router.get('/', getArticles);
router.get('/:id', getArticle);

// 受保护的路由
router.post(
  '/',
  [
    protect,
    [
      check('title', '标题是必需的').not().isEmpty(),
      check('content', '内容是必需的').not().isEmpty(),
      check('type', '类型必须是 article 或 post').isIn(['article', 'post'])
    ]
  ],
  createArticle
);
router.put('/:id', protect, updateArticle);
router.delete('/:id', protect, deleteArticle);
router.put('/:id/like', protect, likeArticle);

module.exports = router;
