const express = require('express');
const { check } = require('express-validator');
const {
  registerUser,
  loginUser,
  getMe,
  updateDetails,
  updatePassword,
  getUsers,
  getUser,
  updateUser,
  deleteUser,
  deactivateUser
} = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// 公开路由
router.post(
  '/register',
  [
    check('username', '用户名是必需的').not().isEmpty(),
    check('email', '请包含有效的电子邮件').isEmail(),
    check('password', '请输入6个或更多字符的密码').isLength({ min: 6 })
  ],
  registerUser
);
router.post('/login', loginUser);

// 受保护的路由
router.get('/me', protect, getMe);
router.put('/me', protect, updateDetails);
router.put('/updatepassword', protect, updatePassword);

// 管理员路由
router.get('/', protect, authorize('admin'), getUsers);
router.get('/:id', protect, authorize('admin'), getUser);
router.put('/:id', protect, authorize('admin'), updateUser);
router.delete('/:id', protect, authorize('admin'), deleteUser);
router.put('/:id/deactivate', protect, authorize('admin'), deactivateUser);

module.exports = router;
