import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import UserCenter from './pages/UserCenter';
import UserSettings from './pages/UserSettings';
import ArticleList from './pages/article/ArticleList';
import ArticleEdit from './pages/article/ArticleEdit';
import ArticleView from './pages/article/ArticleView';
import UserList from './pages/user/UserList';
import UserEdit from './pages/user/UserEdit';
import AppList from './pages/app/AppList';
import AppEdit from './pages/app/AppEdit';
import AnnouncementList from './pages/announcement/AnnouncementList';
import AnnouncementEdit from './pages/announcement/AnnouncementEdit';
import AnnouncementView from './pages/announcement/AnnouncementView';
import NotFound from './pages/NotFound';
import DevelopmentPage from './pages/DevelopmentPage';

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route index element={<Dashboard />} />
            <Route path="user-center" element={<UserCenter />} />
            <Route path="user-settings" element={<UserSettings />} />
            <Route path="articles" element={<ArticleList />} />
            <Route path="articles/add" element={<ArticleEdit />} />
            <Route path="articles/edit/:id" element={<ArticleEdit />} />
            <Route path="articles/view/:id" element={<ArticleView />} />
            <Route path="users" element={<UserList />} />
            <Route path="users/add" element={<UserEdit />} />
            <Route path="users/edit/:id" element={<UserEdit />} />
            <Route path="apps" element={<AppList />} />
            <Route path="apps/add" element={<AppEdit />} />
            <Route path="apps/edit/:id" element={<AppEdit />} />
            <Route path="announcements" element={<AnnouncementList />} />
            <Route path="announcements/add" element={<AnnouncementEdit />} />
            <Route path="announcements/edit/:id" element={<AnnouncementEdit />} />
            <Route path="announcements/view/:id" element={<AnnouncementView />} />
          </Route>
          <Route path="development/:feature" element={<DevelopmentPage />} />
            <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
};

export default App;
