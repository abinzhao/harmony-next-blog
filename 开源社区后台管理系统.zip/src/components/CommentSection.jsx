import React, { useState, useEffect } from 'react';
import { List as AntList, Avatar, Form, Button, Input, Popconfirm, message, Card, Divider, Empty, Spin } from 'antd';
import { UserOutlined, DeleteOutlined, LikeOutlined, LikeFilled } from '@ant-design/icons';
import { useAuth } from '../contexts/AuthContext';
import { mockApi } from '../utils/mockData';

const { TextArea } = Input;

const CommentSection = ({ targetType, targetId }) => {
  const { currentUser } = useAuth();
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [commentValue, setCommentValue] = useState('');
  const [form] = Form.useForm();
  const [likedComments, setLikedComments] = useState({});

  useEffect(() => {
    fetchComments();
  }, [targetType, targetId]);

  const fetchComments = async () => {
    try {
      setLoading(true);
      const data = await mockApi.getComments(targetType, targetId);
      setComments(data);
    } catch (error) {
      console.error('获取评论失败', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!commentValue.trim()) {
      return;
    }

    try {
      setSubmitting(true);
      await mockApi.addComment(
        targetType,
        targetId,
        commentValue,
        currentUser.id,
        currentUser.name
      );
      setCommentValue('');
      form.resetFields();
      message.success('评论发布成功');
      fetchComments();
    } catch (error) {
      message.error('评论发布失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (commentId) => {
    try {
      await mockApi.deleteComment(targetType, targetId, commentId);
      message.success('评论删除成功');
      fetchComments();
    } catch (error) {
      message.error('评论删除失败');
    }
  };

  const handleLike = (commentId) => {
    setLikedComments({
      ...likedComments,
      [commentId]: !likedComments[commentId]
    });
  };

  return (
    <Card 
      title={
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <span>评论区</span>
          <span style={{ marginLeft: '8px', fontSize: '14px', color: '#8c8c8c' }}>
            ({comments.length} 条评论)
          </span>
        </div>
      } 
      bordered={false}
      className="comment-section-card"
    >
      {/* 评论列表 */}
      <Spin spinning={loading}>
        {comments.length > 0 ? (
          <AntList
            dataSource={comments}
            itemLayout="horizontal"
            renderItem={item => (
              <AntList.Item 
                actions={[
                  <span 
                    key="like" 
                    onClick={() => handleLike(item.id)}
                    style={{ cursor: 'pointer' }}
                  >
                    {likedComments[item.id] ? <LikeFilled /> : <LikeOutlined />}
                    <span style={{ marginLeft: 8 }}>
                      {(likedComments[item.id] ? 1 : 0) + Math.floor(Math.random() * 10)}
                    </span>
                  </span>,
                  currentUser && (currentUser.id === item.authorId || currentUser.role === 'admin') && (
                    <Popconfirm
                      key="delete"
                      title="确定要删除这条评论吗？"
                      onConfirm={() => handleDelete(item.id)}
                      okText="确定"
                      cancelText="取消"
                    >
                      <DeleteOutlined />
                    </Popconfirm>
                  )
                ]}
              >
                <AntList.Item.Meta
                  avatar={
                    <Avatar 
                      src={item.avatar} 
                      icon={!item.avatar && <UserOutlined />}
                    >
                      {!item.avatar && item.author.substring(0, 1)}
                    </Avatar>
                  }
                  title={<a>{item.author}</a>}
                  description={
                    <div>
                      <div>{item.content}</div>
                      <div style={{ color: '#8c8c8c', fontSize: '12px', marginTop: '4px' }}>
                        {item.createTime}
                      </div>
                    </div>
                  }
                />
              </AntList.Item>
            )}
          />
        ) : (
          <Empty description="暂无评论" />
        )}
      </Spin>
      
      <Divider />
      
      {/* 发表评论 */}
      {currentUser ? (
        <div className="comment-editor">
          <Form form={form} onFinish={handleSubmit}>
            <Form.Item
              name="comment"
              rules={[{ required: true, message: '请输入评论内容' }]}
            >
              <TextArea 
                rows={4} 
                placeholder="写下你的评论..." 
                value={commentValue}
                onChange={e => setCommentValue(e.target.value)}
              />
            </Form.Item>
            <Form.Item>
              <Button 
                htmlType="submit" 
                type="primary" 
                loading={submitting}
                disabled={!commentValue.trim()}
              >
                发表评论
              </Button>
            </Form.Item>
          </Form>
        </div>
      ) : (
        <div className="comment-login-tip">
          请<a href="#/login">登录</a>后发表评论
        </div>
      )}
    </Card>
  );
};

export default CommentSection;
