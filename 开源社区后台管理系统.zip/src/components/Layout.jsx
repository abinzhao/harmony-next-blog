import React, { useState, useEffect } from 'react';
import { Layout, Menu, Avatar, Dropdown, Space, Breadcrumb, Badge, Modal, List, Typography, Button, Tooltip, theme, Tag } from 'antd';
import MDEditor from '@uiw/react-md-editor';
import { 
  HomeOutlined, UserOutlined, FileTextOutlined, 
  TeamOutlined, AppstoreOutlined, NotificationOutlined,
  LogoutOutlined, SettingOutlined, MenuFoldOutlined,
  MenuUnfoldOutlined, BellOutlined, ReadOutlined, CommentOutlined,
  WarningOutlined, InfoCircleOutlined, CheckCircleOutlined,
  ClockCircleOutlined
} from '@ant-design/icons';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { mockApi } from '../utils/mockData';

const { Header, Sider, Content } = Layout;
const { Title, Paragraph, Text } = Typography;

const MainLayout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const { currentUser, logout, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [announcements, setAnnouncements] = useState([]);
  const [announcementModalVisible, setAnnouncementModalVisible] = useState(false);
  const [currentAnnouncement, setCurrentAnnouncement] = useState(null);
  const [loading, setLoading] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  
  const { token } = theme.useToken();

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  // 公告优先级对应的配置
  const priorityConfig = {
    high: { 
      color: '#f5222d', 
      label: '高优先级', 
      icon: <WarningOutlined />,
      badge: 'error',
      borderColor: '#ffccc7',
      backgroundColor: '#fff2f0',
      titleColor: '#cf1322',
      dotColor: '#f5222d'
    },
    medium: { 
      color: '#faad14', 
      label: '中优先级', 
      icon: <InfoCircleOutlined />,
      badge: 'warning',
      borderColor: '#ffe58f',
      backgroundColor: '#fffbe6',
      titleColor: '#d48806',
      dotColor: '#faad14'
    },
    low: { 
      color: '#52c41a', 
      label: '低优先级', 
      icon: <CheckCircleOutlined />,
      badge: 'success',
      borderColor: '#b7eb8f',
      backgroundColor: '#f6ffed',
      titleColor: '#389e0d',
      dotColor: '#52c41a'
    }
  };

  // 首次加载时自动显示最新的重要公告
  useEffect(() => {
    if (announcements.length > 0) {
      // 找出第一条高优先级公告
      const highPriorityAnnouncement = announcements.find(a => a.priority === 'high');
      if (highPriorityAnnouncement) {
        showAnnouncementDetail(highPriorityAnnouncement);
      }
    }
  }, [announcements]);

  const fetchAnnouncements = async () => {
    try {
      setLoading(true);
      const data = await mockApi.getAnnouncements();
      setAnnouncements(data);
    } catch (error) {
      console.error('获取公告失败', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const userMenu = (
    <Menu>
      <Menu.Item key="1" icon={<UserOutlined />}>
        <Link to="/user-center">用户中心</Link>
      </Menu.Item>
      <Menu.Item key="2" icon={<SettingOutlined />}>
        <Link to="/user-center">设置</Link>
      </Menu.Item>
      <Menu.Divider />
      <Menu.Item key="3" icon={<LogoutOutlined />} onClick={handleLogout}>
        退出登录
      </Menu.Item>
    </Menu>
  );

  // 显示公告列表
  const showAnnouncementList = () => {
    setCurrentAnnouncement(null);
    setAnnouncementModalVisible(true);
    setHasUnread(false);
  };

  // 显示公告详情
  const showAnnouncementDetail = (announcement) => {
    setCurrentAnnouncement(announcement);
    setAnnouncementModalVisible(true);
    setHasUnread(false);
  };

  // 根据当前路径获取面包屑
  const getBreadcrumb = () => {
    const pathSnippets = location.pathname.split('/').filter(i => i);
    
    const breadcrumbItems = [
      {
        title: <Link to="/">首页</Link>,
      }
    ];

    const breadcrumbNameMap = {
      'user-center': '用户中心',
      'articles': '文章管理',
      'users': '用户管理',
      'apps': '应用管理',
      'announcements': '系统公告',
      'add': '新增',
      'edit': '编辑'
    };

    pathSnippets.forEach((_, index) => {
      const url = `/${pathSnippets.slice(0, index + 1).join('/')}`;
      const name = breadcrumbNameMap[pathSnippets[index]] || pathSnippets[index];
      
      if (index === pathSnippets.length - 1 && /^\d+$/.test(name)) {
        return; // 跳过最后一个数字ID
      }
      
      breadcrumbItems.push({
        title: <Link to={url}>{name}</Link>,
      });
    });

    return breadcrumbItems;
  };

  return (
    <Layout>
      <Sider 
        trigger={null} 
        collapsible 
        collapsed={collapsed} 
        theme="dark" 
        width={220}
        style={{ 
          boxShadow: '2px 0 8px rgba(0,0,0,0.15)',
          overflow: 'auto',
          height: '100vh',
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
          zIndex: 10
        }}
      >
        <div className="logo">
          {!collapsed && <span>开源社区管理系统</span>}
        </div>
        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={[location.pathname]}
          defaultSelectedKeys={['/']}
          items={[
            {
              key: '/',
              icon: <HomeOutlined />,
              label: <Link to="/">首页</Link>,
            },
            {
              key: 'content',
              icon: <FileTextOutlined />,
              label: '内容管理',
              children: [
                {
                  key: '/articles',
                  icon: <ReadOutlined />,
                  label: <Link to="/articles">文章管理</Link>,
                },
                {
                  key: '/posts',
                  icon: <CommentOutlined />,
                  label: <Link to="/articles?type=post">帖子管理</Link>,
                }
              ]
            },
            {
              key: '/apps',
              icon: <AppstoreOutlined />,
              label: <Link to="/apps">应用管理</Link>,
            },
            isAdmin && {
              key: '/users',
              icon: <TeamOutlined />,
              label: <Link to="/users">用户管理</Link>,
            },
            isAdmin && {
              key: '/announcements',
              icon: <NotificationOutlined />,
              label: <Link to="/announcements">系统公告</Link>,
            },
          ].filter(Boolean)}
        />
      </Sider>
      <Layout className="site-layout" style={{ marginLeft: collapsed ? 80 : 220, transition: 'all 0.2s' }}>
        <Header 
          className="site-layout-header" 
          style={{ 
            padding: 0, 
            background: token.colorBgContainer,
            boxShadow: '0 2px 8px rgba(0,0,0,0.09)',
            position: 'sticky',
            top: 0,
            zIndex: 9,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center' }}>
            {React.createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined, {
              className: 'trigger',
              style: { fontSize: '18px', padding: '0 24px', cursor: 'pointer' },
              onClick: () => setCollapsed(!collapsed),
            })}
          </div>
          <div className="header-right">
            <Space size="large" style={{ marginRight: '24px' }}>
              <Tooltip title="系统公告">
                <Badge dot={hasUnread}>
                  <BellOutlined 
                    style={{ fontSize: '18px', cursor: 'pointer' }} 
                    onClick={showAnnouncementList}
                  />
                </Badge>
              </Tooltip>
              <Dropdown menu={{ items: [
                {
                  key: '1',
                  icon: <UserOutlined />,
                  label: <Link to="/user-center">用户中心</Link>,
                },
                {
                  key: '2',
                  icon: <SettingOutlined />,
                  label: <Link to="/user-center">设置</Link>,
                },
                {
                  type: 'divider',
                },
                {
                  key: '3',
                  icon: <LogoutOutlined />,
                  label: '退出登录',
                  onClick: handleLogout
                }
              ]}} placement="bottomRight">
                <Space style={{ cursor: 'pointer' }}>
                  <Avatar src={currentUser?.avatar} />
                  <span style={{ color: token.colorText }}>{currentUser?.name}</span>
                </Space>
              </Dropdown>
            </Space>
          </div>
        </Header>
        <div className="breadcrumb-container" style={{ padding: '16px 24px 0', background: token.colorBgContainer }}>
          <Breadcrumb items={getBreadcrumb()} />
        </div>
        <Content style={{ margin: '16px 24px 24px', overflow: 'initial' }}>
          <div className="site-layout-content" style={{ 
            padding: '24px', 
            background: token.colorBgContainer, 
            borderRadius: token.borderRadius,
            minHeight: 'calc(100vh - 170px)'
          }}>
            <Outlet />
          </div>
        </Content>
      </Layout>

      {/* 公告模态框 */}
      <Modal
        open={announcementModalVisible}
        title={
          currentAnnouncement ? (
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {currentAnnouncement.priority === 'high' && (
                <WarningOutlined style={{ color: '#f5222d', marginRight: '8px' }} />
              )}
              {currentAnnouncement.priority === 'medium' && (
                <InfoCircleOutlined style={{ color: '#faad14', marginRight: '8px' }} />
              )}
              {currentAnnouncement.priority === 'low' && (
                <CheckCircleOutlined style={{ color: '#52c41a', marginRight: '8px' }} />
              )}
              <span>{currentAnnouncement.title}</span>
            </div>
          ) : "系统公告"
        }
        footer={
          currentAnnouncement ? (
            <Button type="primary" onClick={() => setAnnouncementModalVisible(false)}>
              我知道了
            </Button>
          ) : null
        }
        onCancel={() => setAnnouncementModalVisible(false)}
        width={currentAnnouncement ? 700 : 520}
        bodyStyle={{ 
          maxHeight: '70vh', 
          overflow: 'auto',
          padding: currentAnnouncement ? '0' : '0'
        }}
      >
        {currentAnnouncement ? (
          <div>
            {/* 根据优先级设置不同样式 */}
            {(() => {
              const priorityInfo = priorityConfig[currentAnnouncement.priority] || priorityConfig.medium;
              return (
                <div style={{ 
                  backgroundColor: priorityInfo.backgroundColor,
                  borderTop: `1px solid ${priorityInfo.borderColor}`,
                  borderBottom: `1px solid ${priorityInfo.borderColor}`
                }}>
                  <div style={{ padding: '16px 24px', display: 'flex', alignItems: 'center' }}>
                    <Tag color={priorityInfo.color} icon={priorityInfo.icon}>
                      {priorityInfo.label}
                    </Tag>
                    <span style={{ marginLeft: '12px', color: '#8c8c8c' }}>
                      <ClockCircleOutlined style={{ marginRight: '4px' }} />
                      {currentAnnouncement.createTime}
                    </span>
                    <span style={{ marginLeft: '12px', color: '#8c8c8c' }}>
                      <UserOutlined style={{ marginRight: '4px' }} />
                      {currentAnnouncement.author}
                    </span>
                  </div>
                </div>
              );
            })()}
            <div style={{ padding: '24px', backgroundColor: 'white' }}>
              <MDEditor.Markdown source={currentAnnouncement.content} />
            </div>
          </div>
        ) : (
          <List
            loading={loading}
            dataSource={announcements}
            renderItem={item => {
              const priorityInfo = priorityConfig[item.priority] || priorityConfig.medium;
              return (
                <List.Item 
                  onClick={() => showAnnouncementDetail(item)}
                  style={{ 
                    cursor: 'pointer', 
                    backgroundColor: item.priority === 'high' ? '#fff1f0' : 'transparent',
                    transition: 'background-color 0.3s'
                  }}
                  className="announcement-list-item"
                >
                  <List.Item.Meta
                    avatar={
                      <div 
                        style={{ 
                          width: '8px', 
                          height: '8px', 
                          borderRadius: '50%', 
                          backgroundColor: priorityInfo.color,
                          marginTop: '8px'
                        }} 
                      />
                    }
                    title={
                      <div style={{ color: priorityInfo.titleColor }}>
                        {item.title}
                        <Tag 
                          color={priorityInfo.color} 
                          icon={priorityInfo.icon}
                          style={{ marginLeft: '8px', fontSize: '12px' }}
                        >
                          {priorityInfo.label}
                        </Tag>
                      </div>
                    }
                    description={
                      <Space direction="vertical" size={0} style={{ width: '100%' }}>
                        <Text type="secondary" ellipsis style={{ maxWidth: '100%' }}>
                          {item.content.replace(/#+\s(.*)|<[^>]+>/g, '$1').substring(0, 60)}...
                        </Text>
                        <Text type="secondary">发布时间: {item.createTime}</Text>
                      </Space>
                    }
                  />
                </List.Item>
              );
            }}
          />
        )}
      </Modal>
    </Layout>
  );
};

export default MainLayout;
