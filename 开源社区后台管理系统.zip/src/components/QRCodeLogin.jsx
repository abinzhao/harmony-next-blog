import React, { useState, useEffect } from 'react';
import { Card, Spin, Button, message, Divider, Typography, Row, Col } from 'antd';
import { QrcodeOutlined, MobileOutlined, SyncOutlined, CheckCircleOutlined } from '@ant-design/icons';
import './QRCodeLogin.css';

const { Title, Text } = Typography;

/**
 * 扫码登录组件
 * @param {Object} props 组件属性
 * @param {Function} props.onLoginSuccess 登录成功回调
 * @param {Function} props.onCancel 取消回调
 */
const QRCodeLogin = ({ onLoginSuccess, onCancel }) => {
  const [status, setStatus] = useState('loading'); // loading, ready, scanning, success, expired
  const [countdown, setCountdown] = useState(60);
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  
  // 模拟生成二维码
  useEffect(() => {
    // 实际项目中应该从后端获取二维码图片URL
    setTimeout(() => {
      setQrCodeUrl('https://source.unsplash.com/random/200x200?qrcode');
      setStatus('ready');
    }, 1000);
    
    return () => {
      // 清理定时器等资源
    };
  }, []);
  
  // 倒计时处理
  useEffect(() => {
    if (status !== 'ready' && status !== 'scanning') return;
    
    if (countdown <= 0) {
      setStatus('expired');
      return;
    }
    
    const timer = setTimeout(() => {
      setCountdown(countdown - 1);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [countdown, status]);
  
  // 模拟扫码状态更新
  useEffect(() => {
    if (status !== 'ready') return;
    
    // 模拟用户扫码
    const scanTimer = setTimeout(() => {
      setStatus('scanning');
      
      // 模拟登录成功
      const successTimer = setTimeout(() => {
        setStatus('success');
        if (onLoginSuccess) {
          onLoginSuccess();
        }
      }, 3000);
      
      return () => clearTimeout(successTimer);
    }, 5000);
    
    return () => clearTimeout(scanTimer);
  }, [status, onLoginSuccess]);
  
  // 刷新二维码
  const refreshQRCode = () => {
    setStatus('loading');
    setCountdown(60);
    
    // 模拟刷新
    setTimeout(() => {
      setQrCodeUrl(`https://source.unsplash.com/random/200x200?qrcode&t=${Date.now()}`);
      setStatus('ready');
    }, 1000);
  };
  
  return (
    <div className="qrcode-login-container">
      <Card className="qrcode-card">
        <Title level={3} className="qrcode-title">
          <QrcodeOutlined /> 扫码登录
        </Title>
        <Text type="secondary" className="qrcode-subtitle">
          请使用<span className="app-name">鸿蒙易测社区</span>APP扫码登录
        </Text>
        
        <div className="qrcode-content">
          <div className="qrcode-wrapper">
            {status === 'loading' && (
              <div className="qrcode-loading">
                <Spin size="large" />
                <div className="loading-text">二维码生成中...</div>
              </div>
            )}
            
            {status !== 'loading' && (
              <div className={`qrcode-image ${status === 'expired' ? 'expired' : ''}`}>
                <img src={qrCodeUrl} alt="登录二维码" />
                
                {status === 'scanning' && (
                  <div className="qrcode-scanning-mask">
                    <div className="scanning-icon">
                      <MobileOutlined />
                    </div>
                    <div className="scanning-text">扫描成功</div>
                    <div className="scanning-subtext">请在手机上确认登录</div>
                  </div>
                )}
                
                {status === 'success' && (
                  <div className="qrcode-success-mask">
                    <div className="success-icon">
                      <CheckCircleOutlined />
                    </div>
                    <div className="success-text">登录成功</div>
                    <div className="success-subtext">正在跳转...</div>
                  </div>
                )}
                
                {status === 'expired' && (
                  <div className="qrcode-expired-mask">
                    <div className="expired-text">二维码已过期</div>
                    <Button 
                      type="primary" 
                      icon={<SyncOutlined />} 
                      onClick={refreshQRCode}
                      className="refresh-button"
                    >
                      刷新二维码
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            {(status === 'ready' || status === 'scanning') && (
              <div className="qrcode-countdown">
                <Text type="secondary">二维码有效时间：{countdown}秒</Text>
              </div>
            )}
          </div>
          
          <div className="qrcode-instructions">
            <div className="step-item">
              <div className="step-number">1</div>
              <div className="step-text">打开<span className="app-name">鸿蒙易测社区</span>APP</div>
            </div>
            <div className="step-item">
              <div className="step-number">2</div>
              <div className="step-text">点击右上角扫一扫图标</div>
            </div>
            <div className="step-item">
              <div className="step-number">3</div>
              <div className="step-text">扫描左侧二维码完成登录</div>
            </div>
          </div>
        </div>
        
        <Divider />
        
        <div className="qrcode-footer">
          <Row gutter={16} justify="center">
            <Col>
              <Button onClick={onCancel}>返回账号密码登录</Button>
            </Col>
            <Col>
              <Button
                type="link"
                onClick={() => message.info('请下载鸿蒙易测社区APP')}
              >
                下载APP
              </Button>
            </Col>
          </Row>
        </div>
      </Card>
    </div>
  );
};

export default QRCodeLogin;
