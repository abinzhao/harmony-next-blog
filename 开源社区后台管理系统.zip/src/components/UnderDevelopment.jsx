import React from 'react';
import { Result, Button } from 'antd';
import { ToolOutlined, RocketOutlined, HomeOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import './UnderDevelopment.css';

/**
 * 功能开发中展示组件
 * @param {Object} props 组件属性
 * @param {string} props.title 自定义标题
 * @param {string} props.description 自定义描述
 * @param {React.ReactNode} props.icon 自定义图标
 * @param {boolean} props.showHomeButton 是否显示返回首页按钮
 * @param {boolean} props.showBackButton 是否显示返回上一页按钮
 */
const UnderDevelopment = ({
  title = '功能开发中',
  description = '该功能正在开发中，敬请期待！',
  icon = <RocketOutlined />,
  showHomeButton = true,
  showBackButton = true
}) => {
  const navigate = useNavigate();

  return (
    <div className="under-development-container">
      <Result
        icon={<div className="custom-result-icon">{icon}</div>}
        title={<div className="result-title">{title}</div>}
        subTitle={<div className="result-subtitle">{description}</div>}
        extra={
          <div className="result-actions">
            {showBackButton && (
              <Button 
                type="default" 
                onClick={() => navigate(-1)}
                className="action-button back-button"
              >
                返回上一页
              </Button>
            )}
            {showHomeButton && (
              <Button 
                type="primary" 
                onClick={() => navigate('/')}
                icon={<HomeOutlined />}
                className="action-button home-button"
              >
                返回首页
              </Button>
            )}
          </div>
        }
      />
      <div className="development-animation">
        <div className="gear-container">
          <ToolOutlined className="gear gear-1" />
          <ToolOutlined className="gear gear-2" />
        </div>
      </div>
    </div>
  );
};

export default UnderDevelopment;
