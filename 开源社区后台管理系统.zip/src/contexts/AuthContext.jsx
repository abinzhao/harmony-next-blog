import React, { createContext, useState, useEffect, useContext } from 'react';
import { message } from 'antd';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 从localStorage获取用户信息
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // 登录
  const login = (username, password) => {
    // 模拟API调用
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // 预设管理员账号
        if (username === 'admin' && password === 'admin123') {
          const adminUser = {
            id: 1,
            username: 'admin',
            name: '管理员',
            email: 'admin@example.com',
            role: 'admin',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
          };
          setCurrentUser(adminUser);
          localStorage.setItem('currentUser', JSON.stringify(adminUser));
          resolve(adminUser);
        } 
        // 预设普通用户账号
        else if (username === 'user' && password === 'user123') {
          const normalUser = {
            id: 2,
            username: 'user',
            name: '普通用户',
            email: 'user@example.com',
            role: 'user',
            avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
          };
          setCurrentUser(normalUser);
          localStorage.setItem('currentUser', JSON.stringify(normalUser));
          resolve(normalUser);
        } else {
          reject(new Error('用户名或密码错误'));
        }
      }, 500);
    });
  };

  // 注册
  const register = (values) => {
    // 模拟API调用
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const newUser = {
          id: Date.now(),
          ...values,
          role: 'user',
          avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
        };
        message.success('注册成功，请登录');
        resolve(newUser);
      }, 500);
    });
  };

  // 登出
  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  // 更新用户信息
  const updateUserInfo = (updatedInfo) => {
    const updatedUser = { ...currentUser, ...updatedInfo };
    setCurrentUser(updatedUser);
    localStorage.setItem('currentUser', JSON.stringify(updatedUser));
  };

  const value = {
    currentUser,
    login,
    register,
    logout,
    updateUserInfo,
    isAdmin: currentUser?.role === 'admin',
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
