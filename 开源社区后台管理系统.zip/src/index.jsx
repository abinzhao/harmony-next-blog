import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import './styles/index.css';
import './styles/app.css';
import './styles/article.css';
import './styles/dashboard.css';
import './styles/login.css';
import './styles/announcement.css';
import './styles/article-view.css';
import './styles/user-center.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ConfigProvider
    locale={zhCN}
    theme={{
      token: {
        colorPrimary: '#1890ff',
      },
    }}
  >
    <App />
  </ConfigProvider>
);
