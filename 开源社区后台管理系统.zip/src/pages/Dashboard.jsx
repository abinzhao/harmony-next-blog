import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Statistic, Alert, List, Typography, Divider, Button, Tag, Badge } from 'antd';
import MDEditor from '@uiw/react-md-editor';
import { 
  FileTextOutlined, 
  TeamOutlined, 
  AppstoreOutlined, 
  NotificationOutlined,
  RightOutlined,
  CommentOutlined,
  CalendarOutlined,
  UserOutlined,
  SettingOutlined,
  WarningOutlined,
  InfoCircleOutlined,
  CheckCircleOutlined
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { mockApi } from '../utils/mockData';

const { Title, Paragraph, Text } = Typography;

const Dashboard = () => {
  const { currentUser, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    articles: 0,
    posts: 0,
    users: 0,
    apps: 0,
    announcements: 0
  });
  const [latestAnnouncements, setLatestAnnouncements] = useState([]);
  const [recentActivity, setRecentActivity] = useState([]);
  
  // 公告优先级对应的配置
  const priorityConfig = {
    high: { 
      color: '#f5222d', 
      label: '高优先级', 
      icon: <WarningOutlined />,
      badge: 'error',
      borderColor: '#ffccc7',
      backgroundColor: '#fff2f0',
      titleColor: '#cf1322'
    },
    medium: { 
      color: '#faad14', 
      label: '中优先级', 
      icon: <InfoCircleOutlined />,
      badge: 'warning',
      borderColor: '#ffe58f',
      backgroundColor: '#fffbe6',
      titleColor: '#d48806'
    },
    low: { 
      color: '#52c41a', 
      label: '低优先级', 
      icon: <CheckCircleOutlined />,
      badge: 'success',
      borderColor: '#b7eb8f',
      backgroundColor: '#f6ffed',
      titleColor: '#389e0d'
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // 获取统计数据
        const articles = await mockApi.getArticles(isAdmin ? null : currentUser.id);
        const apps = await mockApi.getApps(isAdmin ? null : currentUser.id);
        
        // 区分文章和帖子
        const articleCount = articles.filter(a => a.type === 'article').length;
        const postCount = articles.filter(a => a.type === 'post').length;
        
        let users = [];
        if (isAdmin) {
          users = await mockApi.getUsers();
        }
        
        const announcements = await mockApi.getAnnouncements();
        
        setStats({
          articles: articleCount,
          posts: postCount,
          users: isAdmin ? users.length : 0,
          apps: apps.length,
          announcements: isAdmin ? announcements.length : 0
        });
        
        // 获取最新公告
        setLatestAnnouncements(announcements.slice(0, 3));
        
        // 模拟最近活动数据
        setRecentActivity([
          {
            id: 1,
            type: 'article',
            action: '发布了文章',
            title: 'React 18 新特性解析',
            time: '2小时前',
            user: '管理员'
          },
          {
            id: 2,
            type: 'app',
            action: '更新了应用',
            title: '社区论坛',
            time: '昨天',
            user: '管理员'
          },
          {
            id: 3,
            type: 'post',
            action: '发布了帖子',
            title: '分享一个好用的VS Code插件',
            time: '3天前',
            user: '普通用户'
          }
        ]);
        
      } catch (error) {
        console.error('获取数据失败', error);
      }
    };
    
    fetchData();
  }, [currentUser, isAdmin]);
  
  // 获取当前日期和时间
  const getCurrentDate = () => {
    const now = new Date();
    const date = now.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    const weekday = now.toLocaleDateString('zh-CN', { weekday: 'long' });
    
    return { date, weekday };
  };
  
  const { date, weekday } = getCurrentDate();
  
  // 获取问候语
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 6) return '夜深了';
    if (hour < 9) return '早上好';
    if (hour < 12) return '上午好';
    if (hour < 14) return '中午好';
    if (hour < 18) return '下午好';
    if (hour < 22) return '晚上好';
    return '夜深了';
  };

  return (
    <div className="dashboard-container">
      {/* 欢迎横幅 */}
      <div className="welcome-banner fade-in">
        <div className="welcome-content">
          <div className="welcome-title">{getGreeting()}，{currentUser?.name}</div>
          <div className="welcome-subtitle">
            今天是 {date} {weekday}，祝您使用愉快！
          </div>
        </div>
      </div>
      
      {/* 统计卡片 */}
      <div className="stats-container">
        <div className="stat-card fade-in delay-1" onClick={() => navigate('/articles?type=article')}>
          <div className="stat-icon blue">
            <FileTextOutlined />
          </div>
          <div className="stat-value">{stats.articles}</div>
          <div className="stat-label">文章数量</div>
        </div>
        
        <div className="stat-card fade-in delay-1" onClick={() => navigate('/articles?type=post')}>
          <div className="stat-icon green">
            <CommentOutlined />
          </div>
          <div className="stat-value">{stats.posts}</div>
          <div className="stat-label">帖子数量</div>
        </div>
        
        <div className="stat-card fade-in delay-2" onClick={() => navigate('/apps')}>
          <div className="stat-icon orange">
            <AppstoreOutlined />
          </div>
          <div className="stat-value">{stats.apps}</div>
          <div className="stat-label">应用数量</div>
        </div>
        
        {isAdmin && (
          <>
            <div className="stat-card fade-in delay-3" onClick={() => navigate('/users')}>
              <div className="stat-icon purple">
                <TeamOutlined />
              </div>
              <div className="stat-value">{stats.users}</div>
              <div className="stat-label">用户数量</div>
            </div>
          </>
        )}
      </div>
      
      {/* 系统公告 */}
      <div className="announcements-section fade-in delay-2">
        <div className="section-header">
          <div className="section-title">系统公告</div>
          {isAdmin && (
            <Button type="link" onClick={() => navigate('/announcements')}>
              查看全部 <RightOutlined />
            </Button>
          )}
        </div>
        
        {latestAnnouncements.length > 0 ? (
          latestAnnouncements.map((item, index) => {
            const priorityInfo = priorityConfig[item.priority] || priorityConfig.medium;
            return (
              <div 
                className="announcement-card" 
                key={item.id}
                style={{ 
                  backgroundColor: priorityInfo.backgroundColor,
                  borderColor: priorityInfo.borderColor,
                  borderLeft: `4px solid ${priorityInfo.color}`
                }}
                onClick={() => navigate(`/announcements/view/${item.id}`)}
              >
                <div className="announcement-header">
                  <div className="announcement-title" style={{ color: priorityInfo.titleColor }}>
                    <span style={{ marginRight: '8px' }}>{priorityInfo.icon}</span>
                    {item.title}
                  </div>
                </div>
                <div className="announcement-content" style={{ backgroundColor: 'white', padding: '16px', borderRadius: '4px' }}>
                  <MDEditor.Markdown source={item.content.substring(0, 150) + (item.content.length > 150 ? '...' : '')} />
                </div>
                <div className="announcement-footer">
                  <div>发布时间: {item.createTime}</div>
                  <div>发布人: {item.author}</div>
                </div>
              </div>
            );
          })
        ) : (
          <Alert message="暂无公告" type="info" />
        )}
      </div>
      
      {/* 快速入口 */}
      <div className="shortcuts-section fade-in delay-3">
        <div className="section-header">
          <div className="section-title">快速入口</div>
        </div>
        
        <div className="shortcuts-grid">
          <div className="shortcut-card" onClick={() => navigate('/articles')}>
            <div className="shortcut-icon">
              <FileTextOutlined />
            </div>
            <div className="shortcut-title">内容管理</div>
            <div className="shortcut-description">发布、编辑和管理您的文章和帖子</div>
            <div className="shortcut-action">
              <Button type="link" style={{ paddingLeft: 0 }}>
                进入 <RightOutlined />
              </Button>
            </div>
          </div>
          
          <div className="shortcut-card" onClick={() => navigate('/apps')}>
            <div className="shortcut-icon">
              <AppstoreOutlined />
            </div>
            <div className="shortcut-title">应用管理</div>
            <div className="shortcut-description">管理您的应用和项目</div>
            <div className="shortcut-action">
              <Button type="link" style={{ paddingLeft: 0 }}>
                进入 <RightOutlined />
              </Button>
            </div>
          </div>
          
          <div className="shortcut-card" onClick={() => navigate('/user-center')}>
            <div className="shortcut-icon">
              <UserOutlined />
            </div>
            <div className="shortcut-title">用户中心</div>
            <div className="shortcut-description">管理您的个人信息和设置</div>
            <div className="shortcut-action">
              <Button type="link" style={{ paddingLeft: 0 }}>
                进入 <RightOutlined />
              </Button>
            </div>
          </div>
          
          {isAdmin && (
            <div className="shortcut-card" onClick={() => navigate('/users')}>
              <div className="shortcut-icon">
                <TeamOutlined />
              </div>
              <div className="shortcut-title">用户管理</div>
              <div className="shortcut-description">管理系统用户和权限</div>
              <div className="shortcut-action">
                <Button type="link" style={{ paddingLeft: 0 }}>
                  进入 <RightOutlined />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* 最近活动 */}
      <div className="activity-section fade-in delay-4">
        <div className="section-header">
          <div className="section-title">最近活动</div>
        </div>
        
        {recentActivity.length > 0 ? (
          <div className="activity-timeline">
            {recentActivity.map((item) => (
              <div 
                className="activity-item" 
                key={item.id}
                onClick={() => {
                  if (item.type === 'article' || item.type === 'post') {
                    navigate(`/articles/view/${item.id}`);
                  } else if (item.type === 'app') {
                    navigate(`/apps/edit/${item.id}`);
                  }
                }}
              >
                <div className="activity-icon-container">
                  <div className={`activity-icon ${
                    item.type === 'article' ? 'blue' : 
                    item.type === 'post' ? 'green' : 
                    item.type === 'app' ? 'orange' : 'purple'
                  }`}>
                    {item.type === 'article' ? <FileTextOutlined /> : 
                     item.type === 'post' ? <CommentOutlined /> : 
                     item.type === 'app' ? <AppstoreOutlined /> : <UserOutlined />}
                  </div>
                </div>
                <div className="activity-content">
                  <div className="activity-header">
                    <div className="activity-title">
                      <Text strong>{item.user}</Text> {item.action}
                    </div>
                    <div className="activity-time">
                      <CalendarOutlined style={{ marginRight: 4 }} /> {item.time}
                    </div>
                  </div>
                  <div className="activity-body">
                    <div className="activity-description">
                      <Text>{item.title}</Text>
                    </div>
                    <div className="activity-tag">
                      <Tag color={
                        item.type === 'article' ? 'blue' : 
                        item.type === 'post' ? 'green' : 
                        item.type === 'app' ? 'orange' : 'purple'
                      }>
                        {
                          item.type === 'article' ? '文章' : 
                          item.type === 'post' ? '帖子' : 
                          item.type === 'app' ? '应用' : item.type
                        }
                      </Tag>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Alert message="暂无活动" type="info" />
        )}
      </div>
    </div>
  );
};

export default Dashboard;
