import React from 'react';
import { useParams, useLocation } from 'react-router-dom';
import UnderDevelopment from '../components/UnderDevelopment';
import { 
  ToolOutlined, 
  CodeOutlined, 
  ApiOutlined, 
  DesktopOutlined, 
  MobileOutlined,
  CloudOutlined,
  AppstoreOutlined
} from '@ant-design/icons';

const DevelopmentPage = () => {
  const { feature } = useParams();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const title = queryParams.get('title') || '功能开发中';

  // 根据不同的功能路径设置不同的图标和描述
  const getFeatureInfo = () => {
    switch (feature) {
      case 'api':
        return {
          icon: <ApiOutlined />,
          title: 'API管理功能开发中',
          description: '我们正在努力开发API管理功能，该功能将允许您管理和监控API接口。'
        };
      case 'mobile':
        return {
          icon: <MobileOutlined />,
          title: '移动应用管理功能开发中',
          description: '移动应用管理功能正在开发中，该功能将提供移动应用的发布、更新和统计分析。'
        };
      case 'cloud':
        return {
          icon: <CloudOutlined />,
          title: '云服务功能开发中',
          description: '云服务功能正在积极开发中，该功能将提供云存储、云计算和数据同步服务。'
        };
      case 'integration':
        return {
          icon: <AppstoreOutlined />,
          title: '系统集成功能开发中',
          description: '系统集成功能正在开发中，该功能将允许与第三方系统和服务进行无缝集成。'
        };
      case 'analytics':
        return {
          icon: <DesktopOutlined />,
          title: '数据分析功能开发中',
          description: '数据分析功能正在开发中，该功能将提供强大的数据可视化和分析工具。'
        };
      default:
        return {
          icon: <CodeOutlined />,
          title: title,
          description: '该功能正在积极开发中，我们的团队正在努力尽快完成并发布。感谢您的耐心等待！'
        };
    }
  };

  const featureInfo = getFeatureInfo();

  return (
    <UnderDevelopment
      title={featureInfo.title}
      description={featureInfo.description}
      icon={featureInfo.icon}
    />
  );
};

export default DevelopmentPage;
