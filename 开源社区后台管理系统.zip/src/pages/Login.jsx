import React, { useState } from 'react';
import { Form, Input, Button, Checkbox, message, Tabs, Divider } from 'antd';
import { 
  UserOutlined, 
  LockOutlined, 
  MobileOutlined, 
  QrcodeOutlined,
  GithubOutlined,
  GoogleOutlined,
  WechatOutlined
} from '@ant-design/icons';
import QRCodeLogin from '../components/QRCodeLogin';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const { TabPane } = Tabs;

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [loginType, setLoginType] = useState('account');
  const [showQRCode, setShowQRCode] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = location.state?.from?.pathname || '/';

  const onFinish = async (values) => {
    try {
      setLoading(true);
      await login(values.username, values.password);
      message.success('登录成功');
      navigate(from, { replace: true });
    } catch (error) {
      message.error(error.message || '登录失败，请检查用户名和密码');
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (key) => {
    setLoginType(key);
  };

  // 模拟二维码图片URL
  const qrCodeUrl = 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fHFyJTIwY29kZXxlbnwwfHwwfHx8MA%3D%3D';

  return (
    <div className="auth-container">
      {/* 背景动画元素 */}
      <div className="auth-bg-animation">
        <div className="auth-bg-circle auth-bg-circle-1"></div>
        <div className="auth-bg-circle auth-bg-circle-2"></div>
        <div className="auth-bg-circle auth-bg-circle-3"></div>
      </div>
    
      <div className="auth-form-container">
        <div className="auth-logo">
          <img src="https://images.unsplash.com/photo-1633409361618-c73427e4e206?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Logo" />
        </div>
        
        <h1 className="auth-title">鸿蒙易测社区管理后台</h1>
        
        <Tabs activeKey={loginType} onChange={handleTabChange} centered>
          <TabPane tab="账号密码登录" key="account">
            <Form
              name="login"
              className="auth-form"
              initialValues={{ remember: true }}
              onFinish={onFinish}
              size="large"
            >
              <Form.Item
                name="username"
                rules={[{ required: true, message: '请输入用户名' }]}
              >
                <Input prefix={<UserOutlined />} placeholder="用户名" />
              </Form.Item>
              <Form.Item
                name="password"
                rules={[{ required: true, message: '请输入密码' }]}
              >
                <Input.Password prefix={<LockOutlined />} placeholder="密码" />
              </Form.Item>
              <Form.Item>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Form.Item name="remember" valuePropName="checked" noStyle>
                    <Checkbox>记住我</Checkbox>
                  </Form.Item>
                  <a href="#">忘记密码</a>
                </div>
              </Form.Item>
              <Form.Item>
                <Button 
                  type="primary" 
                  htmlType="submit" 
                  style={{ width: '100%' }}
                  loading={loading}
                >
                  登录
                </Button>
              </Form.Item>
            </Form>
          </TabPane>
          
          <TabPane tab="手机号登录" key="mobile">
            <Form
              name="mobile_login"
              className="auth-form"
              initialValues={{ remember: true }}
              size="large"
            >
              <Form.Item
                name="mobile"
                rules={[{ required: true, message: '请输入手机号' }]}
              >
                <Input prefix={<MobileOutlined />} placeholder="手机号" />
              </Form.Item>
              <Form.Item
                name="captcha"
                rules={[{ required: true, message: '请输入验证码' }]}
              >
                <div style={{ display: 'flex' }}>
                  <Input 
                    style={{ flex: 1 }} 
                    prefix={<QrcodeOutlined />} 
                    placeholder="验证码" 
                  />
                  <Button 
                    style={{ marginLeft: 8, width: 120 }}
                  >
                    获取验证码
                  </Button>
                </div>
              </Form.Item>
              <Form.Item>
                <Button 
                  type="primary" 
                  style={{ width: '100%' }}
                >
                  登录
                </Button>
              </Form.Item>
            </Form>
          </TabPane>
          
          <TabPane tab="扫码登录" key="qrcode">
            {showQRCode ? (
              <QRCodeLogin 
                onLoginSuccess={() => {
                  message.success('扫码登录成功');
                  setTimeout(() => navigate('/'), 1500);
                }}
                onCancel={() => setShowQRCode(false)}
              />
            ) : (
              <div className="auth-qrcode-container">
                <div className="auth-qrcode">
                  <img src={qrCodeUrl} alt="登录二维码" style={{ width: '100%', height: '100%' }} />
                </div>
                <p className="auth-qrcode-text">
                  请使用<span style={{ color: '#1890ff', fontWeight: 'bold' }}>鸿蒙易测社区</span>APP扫描二维码登录
                </p>
                <p className="auth-qrcode-text" style={{ color: '#1890ff' }}>
                  <Button type="link" onClick={() => setShowQRCode(true)}>
                    <MobileOutlined /> 点击体验完整扫码登录流程
                  </Button>
                </p>
              </div>
            )}
          </TabPane>
        </Tabs>
        
        <div className="auth-divider">
          <span>其他登录方式</span>
        </div>
        
        <div className="auth-social-login">
          <div className="auth-social-button">
            <GithubOutlined />
          </div>
          <div className="auth-social-button">
            <WechatOutlined style={{ color: '#07C160' }} />
          </div>
          <div className="auth-social-button">
            <GoogleOutlined style={{ color: '#DB4437' }} />
          </div>
        </div>
        
        <div className="auth-switch-mode">
          还没有账号？ <Link to="/register">立即注册</Link>
        </div>
        
        <div className="auth-test-accounts">
          <p>测试账号：</p>
          <p>管理员：<code>admin / admin123</code></p>
          <p>用户：<code>user / user123</code></p>
        </div>
      </div>
    </div>
  );
};

export default Login;
