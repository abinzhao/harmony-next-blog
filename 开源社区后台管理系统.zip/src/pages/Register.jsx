import React, { useState } from 'react';
import { Form, Input, Button, message, Steps, Divider, Result } from 'antd';
import { 
  UserOutlined, 
  LockOutlined, 
  MailOutlined, 
  UserAddOutlined, 
  MobileOutlined, 
  SafetyOutlined,
  CheckCircleOutlined,
  GithubOutlined,
  WechatOutlined,
  GoogleOutlined
} from '@ant-design/icons';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const { Step } = Steps;

const Register = () => {
  const [loading, setLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [formValues, setFormValues] = useState({});
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form] = Form.useForm();

  const onFinish = async (values) => {
    if (currentStep === 0) {
      // 第一步：基本信息
      setFormValues({ ...formValues, ...values });
      setCurrentStep(1);
    } else if (currentStep === 1) {
      // 第二步：账号安全
      if (values.password !== values.confirmPassword) {
        message.error('两次输入的密码不一致');
        return;
      }
      
      const completeValues = { ...formValues, ...values };
      setFormValues(completeValues);
      
      try {
        setLoading(true);
        await register({
          username: completeValues.username,
          name: completeValues.name,
          email: completeValues.email,
          password: completeValues.password
        });
        setCurrentStep(2);
      } catch (error) {
        message.error(error.message || '注册失败，请稍后再试');
      } finally {
        setLoading(false);
      }
    }
  };

  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleLoginRedirect = () => {
    navigate('/login');
  };

  // 渲染不同步骤的表单
  const renderStepContent = () => {
    if (currentStep === 0) {
      // 第一步：基本信息
      return (
        <Form
          name="register_step1"
          className="auth-form"
          form={form}
          initialValues={formValues}
          onFinish={onFinish}
          size="large"
        >
          <Form.Item
            name="username"
            rules={[
              { required: true, message: '请输入用户名' },
              { min: 3, message: '用户名至少3个字符' }
            ]}
          >
            <Input prefix={<UserOutlined />} placeholder="用户名" />
          </Form.Item>
          <Form.Item
            name="name"
            rules={[{ required: true, message: '请输入姓名' }]}
          >
            <Input prefix={<UserAddOutlined />} placeholder="姓名" />
          </Form.Item>
          <Form.Item
            name="email"
            rules={[
              { required: true, message: '请输入邮箱' },
              { type: 'email', message: '请输入有效的邮箱地址' }
            ]}
          >
            <Input prefix={<MailOutlined />} placeholder="邮箱" />
          </Form.Item>
          <Form.Item
            name="mobile"
            rules={[
              { required: true, message: '请输入手机号' },
              { pattern: /^1\d{10}$/, message: '请输入有效的手机号' }
            ]}
          >
            <Input prefix={<MobileOutlined />} placeholder="手机号" />
          </Form.Item>
          <Form.Item>
            <Button 
              type="primary" 
              htmlType="submit" 
              style={{ width: '100%' }}
            >
              下一步
            </Button>
          </Form.Item>
        </Form>
      );
    } else if (currentStep === 1) {
      // 第二步：账号安全
      return (
        <Form
          name="register_step2"
          className="auth-form"
          initialValues={formValues}
          onFinish={onFinish}
          size="large"
        >
          <Form.Item
            name="password"
            rules={[
              { required: true, message: '请输入密码' },
              { min: 6, message: '密码至少6个字符' }
            ]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="密码" />
          </Form.Item>
          <Form.Item
            name="confirmPassword"
            rules={[
              { required: true, message: '请确认密码' },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue('password') === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(new Error('两次输入的密码不一致'));
                },
              }),
            ]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="确认密码" />
          </Form.Item>
          <Form.Item
            name="securityQuestion"
            rules={[{ required: true, message: '请选择安全问题' }]}
          >
            <Input prefix={<SafetyOutlined />} placeholder="安全问题（例如：我的出生地）" />
          </Form.Item>
          <Form.Item
            name="securityAnswer"
            rules={[{ required: true, message: '请输入安全问题答案' }]}
          >
            <Input prefix={<SafetyOutlined />} placeholder="安全问题答案" />
          </Form.Item>
          <Form.Item>
            <div style={{ display: 'flex', gap: '16px' }}>
              <Button 
                style={{ flex: 1 }}
                onClick={handlePrevStep}
              >
                上一步
              </Button>
              <Button 
                type="primary" 
                htmlType="submit" 
                style={{ flex: 1 }}
                loading={loading}
              >
                注册
              </Button>
            </div>
          </Form.Item>
        </Form>
      );
    } else {
      // 第三步：注册成功
      return (
        <Result
          status="success"
          title="注册成功！"
          subTitle="您的账号已创建成功，现在可以登录系统了。"
          extra={[
            <Button 
              type="primary" 
              key="login" 
              onClick={handleLoginRedirect}
              size="large"
            >
              立即登录
            </Button>,
          ]}
        />
      );
    }
  };

  return (
    <div className="auth-container">
      {/* 背景动画元素 */}
      <div className="auth-bg-animation">
        <div className="auth-bg-circle auth-bg-circle-1"></div>
        <div className="auth-bg-circle auth-bg-circle-2"></div>
        <div className="auth-bg-circle auth-bg-circle-3"></div>
      </div>
    
      <div className="auth-form-container" style={{ maxWidth: '500px' }}>
        <div className="auth-logo">
          <img src="https://images.unsplash.com/photo-1633409361618-c73427e4e206?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Logo" />
        </div>
        
        <h1 className="auth-title">注册账号</h1>
        
        <Steps
          current={currentStep}
          items={[
            {
              title: '基本信息',
              icon: <UserOutlined />
            },
            {
              title: '账号安全',
              icon: <SafetyOutlined />
            },
            {
              title: '完成',
              icon: <CheckCircleOutlined />
            }
          ]}
          style={{ marginBottom: '32px' }}
        />
        
        {renderStepContent()}
        
        {currentStep !== 2 && (
          <>
            <div className="auth-divider">
              <span>其他方式注册</span>
            </div>
            
            <div className="auth-social-login">
              <div className="auth-social-button">
                <GithubOutlined />
              </div>
              <div className="auth-social-button">
                <WechatOutlined style={{ color: '#07C160' }} />
              </div>
              <div className="auth-social-button">
                <GoogleOutlined style={{ color: '#DB4437' }} />
              </div>
            </div>
            
            <div className="auth-switch-mode">
              已有账号？ <Link to="/login">登录</Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Register;
