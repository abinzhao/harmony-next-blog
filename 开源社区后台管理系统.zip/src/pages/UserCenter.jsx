import React, { useState } from 'react';
import { Card, Avatar, Tabs, Form, Input, Button, Upload, message, Descriptions, Badge } from 'antd';
import { UserOutlined, MailOutlined, LockOutlined, UploadOutlined } from '@ant-design/icons';
import { useAuth } from '../contexts/AuthContext';

const UserCenter = () => {
  const { currentUser, updateUserInfo } = useAuth();
  const [activeTab, setActiveTab] = useState('1');
  const [loading, setLoading] = useState(false);

  const handleProfileUpdate = async (values) => {
    try {
      setLoading(true);
      // 在实际应用中，这里应该调用API更新用户信息
      await new Promise(resolve => setTimeout(resolve, 500));
      
      updateUserInfo({
        name: values.name,
        email: values.email
      });
      
      message.success('个人信息更新成功');
    } catch (error) {
      message.error('更新失败，请稍后再试');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordUpdate = async (values) => {
    try {
      setLoading(true);
      // 在实际应用中，这里应该调用API更新密码
      await new Promise(resolve => setTimeout(resolve, 500));
      
      message.success('密码修改成功');
      
      // 清空表单
      form.resetFields();
    } catch (error) {
      message.error('密码修改失败，请稍后再试');
    } finally {
      setLoading(false);
    }
  };

  const [form] = Form.useForm();

  const items = [
    {
      key: '1',
      label: '个人资料',
      children: (
        <div style={{ maxWidth: '600px', margin: '0 auto' }}>
          <Descriptions
            title="基本信息"
            bordered
            column={1}
            style={{ marginBottom: '24px' }}
          >
            <Descriptions.Item label="用户名">{currentUser?.username}</Descriptions.Item>
            <Descriptions.Item label="姓名">{currentUser?.name}</Descriptions.Item>
            <Descriptions.Item label="邮箱">{currentUser?.email}</Descriptions.Item>
            <Descriptions.Item label="角色">
              <Badge status={currentUser?.role === 'admin' ? 'success' : 'processing'} text={currentUser?.role === 'admin' ? '管理员' : '普通用户'} />
            </Descriptions.Item>
          </Descriptions>
          
          <Card title="修改个人资料" style={{ marginBottom: '24px' }}>
            <Form
              name="profile"
              initialValues={{
                name: currentUser?.name,
                email: currentUser?.email
              }}
              onFinish={handleProfileUpdate}
              layout="vertical"
            >
              <Form.Item
                name="name"
                label="姓名"
                rules={[{ required: true, message: '请输入姓名' }]}
              >
                <Input prefix={<UserOutlined />} />
              </Form.Item>
              <Form.Item
                name="email"
                label="邮箱"
                rules={[
                  { required: true, message: '请输入邮箱' },
                  { type: 'email', message: '请输入有效的邮箱地址' }
                ]}
              >
                <Input prefix={<MailOutlined />} />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit" loading={loading}>
                  保存修改
                </Button>
              </Form.Item>
            </Form>
          </Card>
          
          <Card title="更换头像">
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <Avatar 
                size={64} 
                src={currentUser?.avatar} 
                icon={<UserOutlined />} 
                style={{ marginRight: '16px' }}
              />
              <Upload
                name="avatar"
                showUploadList={false}
                beforeUpload={(file) => {
                  // 这里只是模拟，实际上应该上传到服务器
                  message.success('头像上传成功');
                  return false;
                }}
              >
                <Button icon={<UploadOutlined />}>选择图片</Button>
              </Upload>
            </div>
            <div style={{ marginTop: '8px', color: '#888' }}>
              支持 JPG、PNG 格式，文件小于 2MB
            </div>
          </Card>
        </div>
      ),
    },
    {
      key: '2',
      label: '安全设置',
      children: (
        <div style={{ maxWidth: '600px', margin: '0 auto' }}>
          <Card title="修改密码">
            <Form
              name="password"
              form={form}
              onFinish={handlePasswordUpdate}
              layout="vertical"
            >
              <Form.Item
                name="oldPassword"
                label="当前密码"
                rules={[{ required: true, message: '请输入当前密码' }]}
              >
                <Input.Password prefix={<LockOutlined />} />
              </Form.Item>
              <Form.Item
                name="newPassword"
                label="新密码"
                rules={[
                  { required: true, message: '请输入新密码' },
                  { min: 6, message: '密码至少6个字符' }
                ]}
              >
                <Input.Password prefix={<LockOutlined />} />
              </Form.Item>
              <Form.Item
                name="confirmPassword"
                label="确认新密码"
                rules={[
                  { required: true, message: '请确认新密码' },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      if (!value || getFieldValue('newPassword') === value) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('两次输入的密码不一致'));
                    },
                  }),
                ]}
              >
                <Input.Password prefix={<LockOutlined />} />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit" loading={loading}>
                  修改密码
                </Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      ),
    },
    {
      key: '3',
      label: '通知设置',
      children: (
        <div style={{ maxWidth: '600px', margin: '0 auto' }}>
          <Card title="通知设置">
            <p>此功能正在开发中...</p>
          </Card>
        </div>
      ),
    },
  ];

  return (
    <div className="container">
      <div className="page-header">
        <h2>用户中心</h2>
      </div>
      
      <div style={{ textAlign: 'center', marginBottom: '24px' }}>
        <Avatar 
          size={80} 
          src={currentUser?.avatar} 
          icon={<UserOutlined />} 
          className="user-avatar"
        />
        <h2 style={{ marginTop: '16px', marginBottom: '4px' }}>{currentUser?.name}</h2>
        <p style={{ color: '#888' }}>{currentUser?.role === 'admin' ? '管理员' : '普通用户'}</p>
      </div>
      
      <Tabs 
        activeKey={activeTab}
        onChange={setActiveTab}
        items={items}
      />
    </div>
  );
};

export default UserCenter;
