import React, { useState, useEffect } from 'react';
import { Tabs, Form, Input, Button, Switch, Card, Row, Col, message, Menu } from 'antd';
import { 
  LockOutlined, 
  BellOutlined, 
  SafetyOutlined, 
  MobileOutlined,
  MailOutlined,
  GlobalOutlined,
  UserOutlined
} from '@ant-design/icons';
import { useAuth } from '../contexts/AuthContext';
import { mockApi } from '../utils/mockData';
import './user-settings.css';

const { TabPane } = Tabs;

const UserSettings = () => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('security');
  const [passwordForm] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [mobileVerified, setMobileVerified] = useState(false);
  const [emailVerified, setEmailVerified] = useState(true);

  useEffect(() => {
    // 模拟加载用户验证状态
    setMobileVerified(false);
    setEmailVerified(true);
  }, [currentUser]);

  const handlePasswordSubmit = async (values) => {
    try {
      setLoading(true);
      
      // 模拟更新密码
      await mockApi.updatePassword(currentUser.id, values.newPassword);
      
      message.success('密码更新成功');
      passwordForm.resetFields();
    } catch (error) {
      message.error('密码更新失败');
    } finally {
      setLoading(false);
    }
  };

  const menuItems = [
    {
      key: 'security',
      icon: <SafetyOutlined />,
      label: '账号安全',
    },
    {
      key: 'notifications',
      icon: <BellOutlined />,
      label: '通知设置',
    },
    {
      key: 'privacy',
      icon: <UserOutlined />,
      label: '隐私设置',
    }
  ];

  return (
    <div className="settings-container">
      <div className="page-header">
        <h2>个人设置</h2>
      </div>
      
      <div className="settings-layout">
        <div className="settings-sidebar">
          <Menu
            mode="inline"
            selectedKeys={[activeTab]}
            onClick={({key}) => setActiveTab(key)}
            items={menuItems}
            className="settings-menu"
          />
        </div>
        
        <div className="settings-content">
          {activeTab === 'security' && (
            <div className="settings-security">
              <Card title="账号安全" className="settings-card">
                <div className="security-overview">
                  <div className="security-item">
                    <div className="security-item-info">
                      <div className="security-item-title">
                        <LockOutlined className="security-icon" />
                        <span>登录密码</span>
                      </div>
                      <div className="security-item-desc">
                        定期修改密码可以提高账号安全性
                      </div>
                    </div>
                    <Button 
                      type="link" 
                      onClick={() => passwordForm.resetFields()}
                    >
                      修改
                    </Button>
                  </div>
                  
                  <div className="security-item">
                    <div className="security-item-info">
                      <div className="security-item-title">
                        <MobileOutlined className="security-icon" />
                        <span>手机验证</span>
                        {mobileVerified ? (
                          <span className="verified-tag">已验证</span>
                        ) : (
                          <span className="unverified-tag">未验证</span>
                        )}
                      </div>
                      <div className="security-item-desc">
                        {mobileVerified 
                          ? '已绑定手机：138****9876' 
                          : '绑定手机后，可使用手机号登录，找回密码等'}
                      </div>
                    </div>
                    <Button type="link">
                      {mobileVerified ? '修改' : '绑定'}
                    </Button>
                  </div>
                  
                  <div className="security-item">
                    <div className="security-item-info">
                      <div className="security-item-title">
                        <MailOutlined className="security-icon" />
                        <span>邮箱验证</span>
                        {emailVerified ? (
                          <span className="verified-tag">已验证</span>
                        ) : (
                          <span className="unverified-tag">未验证</span>
                        )}
                      </div>
                      <div className="security-item-desc">
                        {emailVerified 
                          ? `已绑定邮箱：${currentUser?.email}` 
                          : '绑定邮箱后，可使用邮箱登录，找回密码等'}
                      </div>
                    </div>
                    <Button type="link">
                      {emailVerified ? '修改' : '绑定'}
                    </Button>
                  </div>
                </div>
                
                <div className="password-form-section">
                  <div className="section-title">修改密码</div>
                  <Form
                    form={passwordForm}
                    layout="vertical"
                    onFinish={handlePasswordSubmit}
                    className="password-form"
                  >
                    <Row gutter={24}>
                      <Col xs={24} md={12}>
                        <Form.Item
                          name="oldPassword"
                          label="当前密码"
                          rules={[{ required: true, message: '请输入当前密码' }]}
                        >
                          <Input.Password 
                            prefix={<LockOutlined />} 
                            placeholder="当前密码" 
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row gutter={24}>
                      <Col xs={24} md={12}>
                        <Form.Item
                          name="newPassword"
                          label="新密码"
                          rules={[
                            { required: true, message: '请输入新密码' },
                            { min: 6, message: '密码至少6个字符' }
                          ]}
                        >
                          <Input.Password 
                            prefix={<LockOutlined />} 
                            placeholder="新密码" 
                          />
                        </Form.Item>
                      </Col>
                      <Col xs={24} md={12}>
                        <Form.Item
                          name="confirmPassword"
                          label="确认新密码"
                          dependencies={['newPassword']}
                          rules={[
                            { required: true, message: '请确认新密码' },
                            ({ getFieldValue }) => ({
                              validator(_, value) {
                                if (!value || getFieldValue('newPassword') === value) {
                                  return Promise.resolve();
                                }
                                return Promise.reject(new Error('两次输入的密码不一致'));
                              },
                            }),
                          ]}
                        >
                          <Input.Password 
                            prefix={<LockOutlined />} 
                            placeholder="确认新密码" 
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Form.Item>
                      <Button 
                        type="primary" 
                        htmlType="submit" 
                        loading={loading}
                      >
                        更新密码
                      </Button>
                    </Form.Item>
                  </Form>
                </div>
              </Card>
            </div>
          )}
          
          {activeTab === 'notifications' && (
            <div className="settings-notifications">
              <Card title="通知设置" className="settings-card">
                <div className="notification-section">
                  <div className="section-title">系统通知</div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">系统公告</div>
                      <div className="notification-desc">接收系统公告和重要通知</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">活动提醒</div>
                      <div className="notification-desc">接收社区活动和新功能通知</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
                
                <div className="notification-section">
                  <div className="section-title">互动通知</div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">评论通知</div>
                      <div className="notification-desc">当有人评论您的内容时通知您</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">点赞通知</div>
                      <div className="notification-desc">当有人点赞您的内容时通知您</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">回复通知</div>
                      <div className="notification-desc">当有人回复您的评论时通知您</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
                
                <div className="notification-section">
                  <div className="section-title">通知方式</div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">站内通知</div>
                      <div className="notification-desc">在网站内接收通知</div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="notification-item">
                    <div className="notification-info">
                      <div className="notification-title">邮件通知</div>
                      <div className="notification-desc">通过邮件接收通知</div>
                    </div>
                    <Switch />
                  </div>
                </div>
                
                <div className="form-actions">
                  <Button type="primary">保存设置</Button>
                </div>
              </Card>
            </div>
          )}
          
          {activeTab === 'privacy' && (
            <div className="settings-privacy">
              <Card title="隐私设置" className="settings-card">
                <div className="privacy-section">
                  <div className="section-title">个人信息可见性</div>
                  <div className="privacy-item">
                    <div className="privacy-info">
                      <div className="privacy-title">个人资料</div>
                      <div className="privacy-desc">控制谁可以查看您的个人资料</div>
                    </div>
                    <div className="privacy-control">
                      <select className="privacy-select">
                        <option value="public">所有人</option>
                        <option value="friends">仅好友</option>
                        <option value="private">仅自己</option>
                      </select>
                    </div>
                  </div>
                  <div className="privacy-item">
                    <div className="privacy-info">
                      <div className="privacy-title">联系方式</div>
                      <div className="privacy-desc">控制谁可以查看您的联系方式</div>
                    </div>
                    <div className="privacy-control">
                      <select className="privacy-select">
                        <option value="public">所有人</option>
                        <option value="friends" selected>仅好友</option>
                        <option value="private">仅自己</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="privacy-section">
                  <div className="section-title">活动与互动</div>
                  <div className="privacy-item">
                    <div className="privacy-info">
                      <div className="privacy-title">我的文章与帖子</div>
                      <div className="privacy-desc">控制谁可以查看您发布的内容</div>
                    </div>
                    <div className="privacy-control">
                      <select className="privacy-select">
                        <option value="public" selected>所有人</option>
                        <option value="friends">仅好友</option>
                        <option value="private">仅自己</option>
                      </select>
                    </div>
                  </div>
                  <div className="privacy-item">
                    <div className="privacy-info">
                      <div className="privacy-title">我的评论</div>
                      <div className="privacy-desc">控制谁可以查看您的评论</div>
                    </div>
                    <div className="privacy-control">
                      <select className="privacy-select">
                        <option value="public" selected>所有人</option>
                        <option value="friends">仅好友</option>
                        <option value="private">仅自己</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="form-actions">
                  <Button type="primary">保存设置</Button>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserSettings;
