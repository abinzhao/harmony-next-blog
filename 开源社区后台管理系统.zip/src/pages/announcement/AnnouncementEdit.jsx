import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Select, Switch, message, Spin, Space, Card, Radio, Tabs, Badge, Tag } from 'antd';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  NotificationOutlined, 
  WarningOutlined, 
  InfoCircleOutlined, 
  CheckCircleOutlined,
  EyeOutlined,
  EditOutlined
} from '@ant-design/icons';
import MDEditor from '@uiw/react-md-editor';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;
const { TabPane } = Tabs;

// 公告优先级对应的配置
const priorityConfig = {
  high: { 
    color: '#f5222d', 
    label: '高优先级', 
    icon: <WarningOutlined />,
    description: '紧急通知，需要立即关注'
  },
  medium: { 
    color: '#faad14', 
    label: '中优先级', 
    icon: <InfoCircleOutlined />,
    description: '重要通知，请及时关注'
  },
  low: { 
    color: '#52c41a', 
    label: '低优先级', 
    icon: <CheckCircleOutlined />,
    description: '一般通知，可稍后关注'
  }
};

const AnnouncementEdit = () => {
  const [form] = Form.useForm();
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState('medium');
  const [previewMode, setPreviewMode] = useState(false);
  const [activeTab, setActiveTab] = useState('edit');
  const isEdit = !!id;

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      message.error('您没有权限访问此页面');
      return;
    }
    
    if (isEdit) {
      fetchAnnouncement();
    }
  }, [id, isAdmin]);

  const fetchAnnouncement = async () => {
    try {
      setLoading(true);
      const announcement = await mockApi.getAnnouncementById(id);
      
      form.setFieldsValue({
        title: announcement.title,
        status: announcement.status,
        priority: announcement.priority || 'medium'
      });
      
      setPriority(announcement.priority || 'medium');
      setContent(announcement.content);
    } catch (error) {
      message.error('获取公告详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values) => {
    try {
      setSubmitting(true);
      
      const announcementData = {
        ...values,
        content,
        priority
      };
      
      if (isEdit) {
        await mockApi.updateAnnouncement(id, announcementData);
        message.success('更新成功');
      } else {
        await mockApi.createAnnouncement(announcementData, currentUser.id, currentUser.name);
        message.success('创建成功');
      }
      
      navigate('/announcements');
    } catch (error) {
      message.error(isEdit ? '更新失败' : '创建失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePriorityChange = (e) => {
    setPriority(e.target.value);
  };

  const handleTabChange = (key) => {
    setActiveTab(key);
  };

  if (!isAdmin) {
    return null; // 非管理员不显示内容
  }

  const renderPreview = () => {
    return (
      <Card className="announcement-preview-card">
        <div className="announcement-preview-header">
          <div className="announcement-preview-title">
            <Badge 
              color={priorityConfig[priority].color} 
              text={
                <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
                  {form.getFieldValue('title') || '公告标题'}
                </span>
              } 
            />
          </div>
          <div className="announcement-preview-meta">
            <Tag color={priorityConfig[priority].color}>
              {priorityConfig[priority].icon} {priorityConfig[priority].label}
            </Tag>
            <span className="announcement-preview-time">
              发布时间: {new Date().toLocaleString()}
            </span>
          </div>
        </div>
        <div className="announcement-preview-content">
          <MDEditor.Markdown source={content || '公告内容将显示在这里'} />
        </div>
        <div className="announcement-preview-footer">
          <div>发布人: {currentUser?.name}</div>
        </div>
      </Card>
    );
  };

  return (
    <div className="container">
      <div className="page-header">
        <h2>{isEdit ? '编辑公告' : '新增公告'}</h2>
      </div>
      
      <Spin spinning={loading}>
        <Tabs activeKey={activeTab} onChange={handleTabChange} type="card">
          <TabPane 
            tab={
              <span>
                <EditOutlined /> 编辑
              </span>
            } 
            key="edit"
          >
            <div className="form-container">
              <Form
                form={form}
                layout="vertical"
                onFinish={handleSubmit}
                initialValues={{
                  status: 'published',
                  priority: 'medium'
                }}
              >
                <Card title="基本信息" className="announcement-edit-card" bordered={false}>
                  <Form.Item
                    name="title"
                    label="公告标题"
                    rules={[{ required: true, message: '请输入公告标题' }]}
                  >
                    <Input 
                      placeholder="请输入公告标题" 
                      prefix={<NotificationOutlined />}
                      size="large"
                    />
                  </Form.Item>
                  
                  <Form.Item
                    label="公告内容"
                    required
                    rules={[{ required: true, message: '请输入公告内容' }]}
                  >
                    <MDEditor
                      value={content}
                      onChange={setContent}
                      height={400}
                      preview="edit"
                    />
                  </Form.Item>
                </Card>
                
                <Card title="发布设置" className="announcement-edit-card" bordered={false}>
                  <Form.Item label="公告优先级">
                    <Radio.Group 
                      value={priority} 
                      onChange={handlePriorityChange}
                      optionType="button"
                      buttonStyle="solid"
                    >
                      <Radio.Button value="high" style={{ borderColor: '#f5222d', color: priority === 'high' ? '#fff' : '#f5222d' }}>
                        <WarningOutlined /> 高优先级
                      </Radio.Button>
                      <Radio.Button value="medium" style={{ borderColor: '#faad14', color: priority === 'medium' ? '#fff' : '#faad14' }}>
                        <InfoCircleOutlined /> 中优先级
                      </Radio.Button>
                      <Radio.Button value="low" style={{ borderColor: '#52c41a', color: priority === 'low' ? '#fff' : '#52c41a' }}>
                        <CheckCircleOutlined /> 低优先级
                      </Radio.Button>
                    </Radio.Group>
                    <div style={{ marginTop: '8px', color: '#8c8c8c', fontSize: '14px' }}>
                      {priorityConfig[priority].description}
                    </div>
                  </Form.Item>
                  
                  <Form.Item
                    name="status"
                    label="公告状态"
                    rules={[{ required: true, message: '请选择公告状态' }]}
                  >
                    <Select placeholder="请选择公告状态">
                      <Option value="published">
                        <CheckCircleOutlined style={{ color: '#52c41a' }} /> 立即发布
                      </Option>
                      <Option value="draft">
                        <span style={{ color: '#faad14' }}>保存为草稿</span>
                      </Option>
                    </Select>
                  </Form.Item>
                </Card>
                
                <Form.Item>
                  <div style={{ display: 'flex', justifyContent: 'center', gap: '16px', marginTop: '24px' }}>
                    <Button 
                      type="primary" 
                      htmlType="submit" 
                      loading={submitting}
                      size="large"
                    >
                      {isEdit ? '更新公告' : '发布公告'}
                    </Button>
                    <Button 
                      onClick={() => setActiveTab('preview')} 
                      size="large"
                      icon={<EyeOutlined />}
                    >
                      预览
                    </Button>
                    <Button 
                      onClick={() => navigate('/announcements')}
                      size="large"
                    >
                      取消
                    </Button>
                  </div>
                </Form.Item>
              </Form>
            </div>
          </TabPane>
          <TabPane 
            tab={
              <span>
                <EyeOutlined /> 预览
              </span>
            } 
            key="preview"
          >
            {renderPreview()}
            <div style={{ display: 'flex', justifyContent: 'center', gap: '16px', marginTop: '24px' }}>
              <Button 
                type="primary" 
                onClick={() => setActiveTab('edit')}
                size="large"
              >
                返回编辑
              </Button>
              <Button 
                onClick={() => form.submit()} 
                loading={submitting}
                size="large"
              >
                {isEdit ? '更新公告' : '发布公告'}
              </Button>
            </div>
          </TabPane>
        </Tabs>
      </Spin>
    </div>
  );
};

export default AnnouncementEdit;
