import React, { useState, useEffect } from 'react';
import { Table, Button, Space, Popconfirm, Tag, message, Input, Select, Card, List, Avatar, Badge, Tooltip } from 'antd';
import { 
  PlusOutlined, 
  DeleteOutlined, 
  EditOutlined, 
  SearchOutlined,
  WarningOutlined,
  InfoCircleOutlined,
  CheckCircleOutlined,
  EyeOutlined,
  NotificationOutlined
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;

// 公告优先级对应的配置
const priorityConfig = {
  high: { 
    color: '#f5222d', 
    label: '高优先级', 
    icon: <WarningOutlined />,
    badge: 'error'
  },
  medium: { 
    color: '#faad14', 
    label: '中优先级', 
    icon: <InfoCircleOutlined />,
    badge: 'warning'
  },
  low: { 
    color: '#52c41a', 
    label: '低优先级', 
    icon: <CheckCircleOutlined />,
    badge: 'success'
  }
};

const AnnouncementList = () => {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [viewMode, setViewMode] = useState('table'); // 'table' 或 'card'
  const { currentUser, isAdmin } = useAuth();
  const navigate = useNavigate();

  const fetchAnnouncements = async () => {
    try {
      setLoading(true);
      if (isAdmin) {
        const data = await mockApi.getAnnouncements();
        
        // 为了演示，给一些公告添加优先级属性
        const enhancedData = data.map(announcement => ({
          ...announcement,
          priority: announcement.priority || (
            announcement.important ? 'high' : Math.random() > 0.5 ? 'medium' : 'low'
          )
        }));
        
        setAnnouncements(enhancedData);
      } else {
        // 非管理员不应该访问此页面，重定向到首页
        navigate('/');
        message.error('您没有权限访问此页面');
      }
    } catch (error) {
      message.error('获取公告列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
  }, [isAdmin]);

  const handleDelete = async (id) => {
    try {
      await mockApi.deleteAnnouncement(id);
      message.success('删除成功');
      fetchAnnouncements();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const filteredAnnouncements = announcements
    .filter(announcement => {
      const matchesSearch = (
        announcement.title.toLowerCase().includes(searchText.toLowerCase()) ||
        announcement.content.toLowerCase().includes(searchText.toLowerCase())
      );
      
      const matchesPriority = priorityFilter === 'all' || announcement.priority === priorityFilter;
      
      return matchesSearch && matchesPriority;
    });

  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      width: 60,
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      key: 'priority',
      width: 120,
      render: priority => {
        const config = priorityConfig[priority] || priorityConfig.medium;
        return (
          <Tag color={config.color} icon={config.icon}>
            {config.label}
          </Tag>
        );
      },
    },
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      render: text => text,
    },
    {
      title: '作者',
      dataIndex: 'author',
      key: 'author',
      width: 120,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: status => {
        let color = status === 'published' ? 'success' : 'default';
        let text = status === 'published' ? '已发布' : '草稿';
        
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: '发布时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 180,
    },
    {
      title: '操作',
      key: 'action',
      width: 180,
      render: (_, record) => (
        <Space size="small" className="table-actions">
          <Button 
            type="text" 
            size="small" 
            icon={<EyeOutlined />}
            onClick={() => navigate(`/announcements/view/${record.id}`)}
            title="查看"
          />
          <Button 
            type="primary" 
            size="small" 
            icon={<EditOutlined />}
            onClick={() => navigate(`/announcements/edit/${record.id}`)}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这条公告吗？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button 
              danger 
              size="small" 
              icon={<DeleteOutlined />}
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // 卡片视图渲染
  const renderCardView = () => {
    return (
      <List
        grid={{
          gutter: 16,
          xs: 1,
          sm: 1,
          md: 2,
          lg: 3,
          xl: 3,
          xxl: 4,
        }}
        dataSource={filteredAnnouncements}
        renderItem={item => {
          const priorityInfo = priorityConfig[item.priority] || priorityConfig.medium;
          
          return (
            <List.Item>
              <Card
                hoverable
                className="announcement-card"
                actions={[
                  <Tooltip title="查看详情">
                    <EyeOutlined key="view" onClick={() => navigate(`/announcements/view/${item.id}`)} />
                  </Tooltip>,
                  <Tooltip title="编辑">
                    <EditOutlined key="edit" onClick={() => navigate(`/announcements/edit/${item.id}`)} />
                  </Tooltip>,
                  <Popconfirm
                    title="确定要删除这条公告吗？"
                    onConfirm={() => handleDelete(item.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <DeleteOutlined key="delete" />
                  </Popconfirm>,
                ]}
              >
                <div className="announcement-card-header">
                  <Badge status={priorityInfo.badge} text="" />
                  <div className="announcement-card-title" style={{ color: priorityInfo.color }}>
                    {item.title}
                  </div>
                </div>
                <div className="announcement-card-content">
                  <div dangerouslySetInnerHTML={{ 
                    __html: item.content.replace(/<[^>]+>/g, '').substring(0, 100) + '...' 
                  }} />
                </div>
                <div className="announcement-card-footer">
                  <div className="announcement-card-meta">
                    <Avatar size="small" style={{ marginRight: 8 }}>
                      {item.author.substring(0, 1)}
                    </Avatar>
                    <span>{item.author}</span>
                  </div>
                  <div className="announcement-card-time">
                    {item.createTime}
                  </div>
                </div>
              </Card>
            </List.Item>
          );
        }}
      />
    );
  };

  if (!isAdmin) {
    return null; // 非管理员不显示内容
  }

  return (
    <div className="container">
      <div className="page-header">
        <h2>系统公告</h2>
        <Button 
          type="primary" 
          icon={<PlusOutlined />}
          onClick={() => navigate('/announcements/add')}
        >
          新增公告
        </Button>
      </div>
      
      <Card bordered={false} style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
          <Space wrap>
            <Input
              placeholder="搜索公告标题或内容"
              value={searchText}
              onChange={e => setSearchText(e.target.value)}
              style={{ width: '300px' }}
              prefix={<SearchOutlined />}
              allowClear
            />
            <Select
              value={priorityFilter}
              onChange={value => setPriorityFilter(value)}
              style={{ width: '150px' }}
            >
              <Option value="all">全部优先级</Option>
              <Option value="high">
                <Tag color="#f5222d" icon={<WarningOutlined />}>高优先级</Tag>
              </Option>
              <Option value="medium">
                <Tag color="#faad14" icon={<InfoCircleOutlined />}>中优先级</Tag>
              </Option>
              <Option value="low">
                <Tag color="#52c41a" icon={<CheckCircleOutlined />}>低优先级</Tag>
              </Option>
            </Select>
          </Space>
          
          <Space>
            <Button
              type={viewMode === 'table' ? 'primary' : 'default'}
              onClick={() => setViewMode('table')}
            >
              表格视图
            </Button>
            <Button
              type={viewMode === 'card' ? 'primary' : 'default'}
              onClick={() => setViewMode('card')}
            >
              卡片视图
            </Button>
          </Space>
        </div>
      </Card>
      
      {viewMode === 'table' ? (
        <Table
          columns={columns}
          dataSource={filteredAnnouncements}
          rowKey="id"
          loading={loading}
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showTotal: (total) => `共 ${total} 条记录`,
          }}
        />
      ) : (
        renderCardView()
      )}
    </div>
  );
};

export default AnnouncementList;
