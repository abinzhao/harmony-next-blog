import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, Tag, Spin, Divider, Space, Breadcrumb, message, BackTop } from 'antd';
import MDEditor from '@uiw/react-md-editor';
import { 
  WarningOutlined, 
  InfoCircleOutlined, 
  CheckCircleOutlined,
  EditOutlined,
  ArrowLeftOutlined,
  UserOutlined,
  ClockCircleOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

// 公告优先级对应的配置
const priorityConfig = {
  high: { 
    color: '#f5222d', 
    label: '高优先级', 
    icon: <WarningOutlined />,
    badge: 'error',
    borderColor: '#ffccc7',
    backgroundColor: '#fff2f0',
    titleColor: '#cf1322',
    dotColor: '#f5222d'
  },
  medium: { 
    color: '#faad14', 
    label: '中优先级', 
    icon: <InfoCircleOutlined />,
    badge: 'warning',
    borderColor: '#ffe58f',
    backgroundColor: '#fffbe6',
    titleColor: '#d48806',
    dotColor: '#faad14'
  },
  low: { 
    color: '#52c41a', 
    label: '低优先级', 
    icon: <CheckCircleOutlined />,
    badge: 'success',
    borderColor: '#b7eb8f',
    backgroundColor: '#f6ffed',
    titleColor: '#389e0d',
    dotColor: '#52c41a'
  }
};

const AnnouncementView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser, isAdmin } = useAuth();
  const [announcement, setAnnouncement] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnnouncement();
  }, [id]);

  const fetchAnnouncement = async () => {
    try {
      setLoading(true);
      const data = await mockApi.getAnnouncementById(id);
      setAnnouncement(data);
    } catch (error) {
      message.error('获取公告详情失败');
      navigate('/announcements');
    } finally {
      setLoading(false);
    }
  };

  if (!announcement && !loading) {
    return null;
  }

  const priorityInfo = announcement ? (priorityConfig[announcement.priority] || priorityConfig.medium) : priorityConfig.medium;

  return (
    <div className="container">
      <BackTop />
      
      <Breadcrumb style={{ marginBottom: '16px' }}>
        <Breadcrumb.Item><a href="#/">首页</a></Breadcrumb.Item>
        <Breadcrumb.Item><a href="#/announcements">系统公告</a></Breadcrumb.Item>
        <Breadcrumb.Item>公告详情</Breadcrumb.Item>
      </Breadcrumb>
      
      <div className="page-header" style={{ marginBottom: '24px' }}>
        <Button 
          icon={<ArrowLeftOutlined />} 
          onClick={() => navigate('/announcements')}
        >
          返回列表
        </Button>
        
        {isAdmin && (
          <Button 
            type="primary" 
            icon={<EditOutlined />} 
            onClick={() => navigate(`/announcements/edit/${id}`)}
          >
            编辑公告
          </Button>
        )}
      </div>
      
      <Spin spinning={loading}>
        {announcement && (
          <div 
            className="announcement-view-container"
            style={{ 
              backgroundColor: priorityInfo.backgroundColor,
              borderRadius: '8px',
              border: `1px solid ${priorityInfo.borderColor}`,
              overflow: 'hidden'
            }}
          >
            <div 
              className="announcement-view-header"
              style={{ 
                padding: '20px 24px',
                borderBottom: `1px solid ${priorityInfo.borderColor}`,
              }}
            >
              <div 
                className="announcement-view-title-container"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  marginBottom: '12px'
                }}
              >
                <div 
                  className="announcement-priority-dot"
                  style={{
                    width: '10px',
                    height: '10px',
                    borderRadius: '50%',
                    backgroundColor: priorityInfo.dotColor,
                    marginRight: '10px'
                  }}
                ></div>
                <h1 
                  className="announcement-view-title"
                  style={{ 
                    margin: 0,
                    color: priorityInfo.titleColor,
                    fontSize: '24px',
                    fontWeight: 'bold'
                  }}
                >
                  {announcement.title}
                </h1>
              </div>
              
              <div className="announcement-view-meta">
                <Space size="large">
                  <Tag color={priorityInfo.color} icon={priorityInfo.icon}>
                    {priorityInfo.label}
                  </Tag>
                  <span>
                    <ClockCircleOutlined style={{ marginRight: '8px' }} />
                    {announcement.createTime}
                  </span>
                  <span>
                    <UserOutlined style={{ marginRight: '8px' }} />
                    {announcement.author}
                  </span>
                </Space>
              </div>
            </div>
            
            <div 
              className="announcement-view-content"
              style={{ 
                padding: '24px',
                backgroundColor: 'white'
              }}
            >
              <div className="markdown-content">
                <MDEditor.Markdown source={announcement.content} />
              </div>
            </div>
          </div>
        )}
      </Spin>
    </div>
  );
};

export default AnnouncementView;
