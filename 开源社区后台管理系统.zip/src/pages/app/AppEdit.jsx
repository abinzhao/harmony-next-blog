import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Select, Switch, message, Spin, Space, Upload, Avatar, Divider, Card, Row, Col } from 'antd';
import { 
  UploadOutlined, 
  AppstoreOutlined, 
  InboxOutlined, 
  PlusOutlined, 
  DeleteOutlined, 
  EyeOutlined 
} from '@ant-design/icons';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;
const { TextArea } = Input;
const { Dragger } = Upload;

const AppEdit = () => {
  const [form] = Form.useForm();
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [appIcon, setAppIcon] = useState(null);
  const [appPackage, setAppPackage] = useState(null);
  const [appScreenshots, setAppScreenshots] = useState([]);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const isEdit = !!id;

  useEffect(() => {
    if (isEdit) {
      fetchApp();
    }
  }, [id]);

  const fetchApp = async () => {
    try {
      setLoading(true);
      const app = await mockApi.getAppById(id);
      
      form.setFieldsValue({
        name: app.name,
        packageName: app.packageName,
        description: app.description,
        version: app.version,
        isIteration: app.isIteration || false,
        status: app.status === 'online'
      });

      if (app.logo) {
        setAppIcon({
          uid: '-1',
          name: 'app-icon.png',
          status: 'done',
          url: app.logo
        });
      }

      if (app.screenshots && app.screenshots.length > 0) {
        setAppScreenshots(app.screenshots.map((url, index) => ({
          uid: `-${index + 1}`,
          name: `screenshot-${index + 1}.png`,
          status: 'done',
          url
        })));
      }
    } catch (error) {
      message.error('获取应用详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values) => {
    if (!appIcon) {
      message.error('请上传应用图标');
      return;
    }

    if (!appPackage && !isEdit) {
      message.error('请上传应用安装包(.hap)');
      return;
    }

    try {
      setSubmitting(true);
      
      const screenshotUrls = appScreenshots.map(item => item.url || item.thumbUrl);
      
      const appData = {
        ...values,
        logo: appIcon.url || appIcon.thumbUrl,
        packagePath: appPackage ? appPackage.name : undefined,
        screenshots: screenshotUrls,
        status: values.status ? 'online' : 'offline'
      };
      
      if (isEdit) {
        await mockApi.updateApp(id, appData);
        message.success('更新成功');
      } else {
        await mockApi.createApp(appData, currentUser.id, currentUser.name);
        message.success('创建成功');
      }
      
      navigate('/apps');
    } catch (error) {
      message.error(isEdit ? '更新失败' : '创建失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleIconChange = info => {
    if (info.file.status === 'done' || info.file.status === 'uploading') {
      setAppIcon(info.file);
    }
  };

  const handlePackageChange = info => {
    if (info.file.status === 'done' || info.file.status === 'uploading') {
      setAppPackage(info.file);
      
      // 从文件名中提取包名和版本号（模拟）
      const fileName = info.file.name;
      if (fileName.endsWith('.hap') && !isEdit) {
        // 模拟解析包信息，实际中应该从服务器返回
        const packageName = `com.example.${fileName.split('.')[0].toLowerCase()}`;
        const version = '1.0.0';
        
        form.setFieldsValue({
          packageName,
          version
        });
        
        message.success('已自动解析安装包信息');
      }
    }
  };

  const handleScreenshotChange = ({ fileList }) => {
    // 限制最多5张截图
    const limitedFileList = fileList.slice(0, 5);
    setAppScreenshots(limitedFileList);
  };

  const handlePreview = async file => {
    setPreviewImage(file.url || file.thumbUrl);
    setPreviewVisible(true);
  };

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>上传</div>
    </div>
  );

  return (
    <div className="container">
      <div className="page-header">
        <h2>{isEdit ? '编辑应用' : '新增应用'}</h2>
      </div>
      
      <Spin spinning={loading}>
        <div className="form-container">
          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            initialValues={{
              status: true,
              isIteration: false
            }}
          >
            <Card title="基本信息" bordered={false} style={{ marginBottom: '20px' }}>
              <Row gutter={16}>
                <Col span={16}>
                  <Form.Item
                    name="name"
                    label="应用名称"
                    rules={[{ required: true, message: '请输入应用名称' }]}
                  >
                    <Input prefix={<AppstoreOutlined />} placeholder="请输入应用名称" />
                  </Form.Item>
                  
                  <Form.Item
                    name="packageName"
                    label="包名"
                    rules={[{ required: true, message: '请输入应用包名' }]}
                  >
                    <Input placeholder="请输入包名，例如：com.example.app" />
                  </Form.Item>
                  
                  <Form.Item
                    name="description"
                    label="应用描述"
                    rules={[{ required: true, message: '请输入应用描述' }]}
                  >
                    <TextArea rows={4} placeholder="请输入应用描述" />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item
                    label="应用图标"
                    required
                    tooltip="应用图标将显示在应用列表中，建议尺寸256x256px"
                  >
                    <Upload
                      name="logo"
                      listType="picture-card"
                      className="app-icon-uploader"
                      showUploadList={false}
                      beforeUpload={(file) => {
                        const isImage = file.type.startsWith('image/');
                        if (!isImage) {
                          message.error('请上传图片文件!');
                          return false;
                        }
                        return false;
                      }}
                      onChange={handleIconChange}
                    >
                      {appIcon ? (
                        <img 
                          src={appIcon.url || appIcon.thumbUrl || URL.createObjectURL(appIcon.originFileObj)} 
                          alt="应用图标" 
                          style={{ width: '100%' }} 
                        />
                      ) : uploadButton}
                    </Upload>
                    <div style={{ marginTop: '8px', color: '#888' }}>
                      建议尺寸: 256px x 256px
                    </div>
                  </Form.Item>
                </Col>
              </Row>
            </Card>
            
            <Card title="版本信息" bordered={false} style={{ marginBottom: '20px' }}>
              <Row gutter={16}>
                <Col span={12}>
                  <Form.Item
                    name="version"
                    label="版本号"
                    rules={[{ required: true, message: '请输入版本号' }]}
                  >
                    <Input placeholder="请输入版本号，例如：1.0.0" />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item
                    name="isIteration"
                    label="是否为迭代版本"
                    valuePropName="checked"
                  >
                    <Switch checkedChildren="是" unCheckedChildren="否" />
                  </Form.Item>
                </Col>
              </Row>
              
              <Form.Item
                label="应用安装包"
                tooltip={isEdit ? "更新应用时可以选择不上传新的安装包" : "请上传.hap格式的鸿蒙应用安装包"}
                required={!isEdit}
              >
                <Dragger
                  name="file"
                  multiple={false}
                  accept=".hap"
                  beforeUpload={(file) => {
                    const isHap = file.name.endsWith('.hap');
                    if (!isHap) {
                      message.error('请上传.hap格式的鸿蒙应用安装包!');
                      return false;
                    }
                    return false;
                  }}
                  onChange={handlePackageChange}
                  showUploadList={{ showRemoveIcon: true }}
                >
                  <p className="ant-upload-drag-icon">
                    <InboxOutlined />
                  </p>
                  <p className="ant-upload-text">点击或拖拽文件到此区域上传</p>
                  <p className="ant-upload-hint">
                    支持单个.hap格式的鸿蒙应用安装包
                  </p>
                </Dragger>
              </Form.Item>
            </Card>
            
            <Card title="应用截图" bordered={false} style={{ marginBottom: '20px' }}>
              <Form.Item
                label="应用截图（最多5张）"
                tooltip="上传应用的截图，展示应用的界面和功能"
              >
                <Upload
                  listType="picture-card"
                  fileList={appScreenshots}
                  onChange={handleScreenshotChange}
                  onPreview={handlePreview}
                  beforeUpload={(file) => {
                    const isImage = file.type.startsWith('image/');
                    if (!isImage) {
                      message.error('请上传图片文件!');
                      return false;
                    }
                    return false;
                  }}
                >
                  {appScreenshots.length >= 5 ? null : uploadButton}
                </Upload>
                {previewVisible && (
                  <div
                    style={{
                      position: 'fixed',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      zIndex: 1000,
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      background: 'rgba(0, 0, 0, 0.65)'
                    }}
                    onClick={() => setPreviewVisible(false)}
                  >
                    <img
                      alt="预览图"
                      style={{ maxWidth: '80%', maxHeight: '80%' }}
                      src={previewImage}
                    />
                  </div>
                )}
              </Form.Item>
            </Card>
            
            <Card title="发布设置" bordered={false} style={{ marginBottom: '20px' }}>
              <Form.Item
                name="status"
                label="状态"
                valuePropName="checked"
              >
                <Switch checkedChildren="在线" unCheckedChildren="离线" />
              </Form.Item>
            </Card>
            
            <Form.Item>
              <Space>
                <Button type="primary" htmlType="submit" loading={submitting}>
                  {isEdit ? '更新应用' : '创建应用'}
                </Button>
                <Button onClick={() => navigate('/apps')}>
                  取消
                </Button>
              </Space>
            </Form.Item>
          </Form>
        </div>
      </Spin>
    </div>
  );
};

export default AppEdit;
