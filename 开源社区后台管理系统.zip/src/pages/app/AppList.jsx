import React, { useState, useEffect } from 'react';
import { Table, Button, Space, Popconfirm, Tag, message, Input, Avatar, Card, Row, Col, Tooltip, Badge, Image, Select, Drawer } from 'antd';
import { 
  PlusOutlined, 
  DeleteOutlined, 
  EditOutlined, 
  SearchOutlined, 
  AppstoreOutlined, 
  EyeOutlined, 
  DownloadOutlined,
  InfoCircleOutlined
} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;

const AppList = () => {
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [viewMode, setViewMode] = useState('card'); // 'table' or 'card'
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentApp, setCurrentApp] = useState(null);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const { currentUser, isAdmin } = useAuth();
  const navigate = useNavigate();

  const fetchApps = async () => {
    try {
      setLoading(true);
      // 管理员获取所有应用，普通用户只获取自己的应用
      const data = await mockApi.getApps(isAdmin ? null : currentUser.id);
      
      // 添加模拟数据用于展示
      const enhancedData = data.map(app => ({
        ...app,
        packageName: app.packageName || `com.example.${app.name.toLowerCase().replace(/\s/g, '')}`,
        version: app.version || '1.0.0',
        isIteration: app.isIteration !== undefined ? app.isIteration : Math.random() > 0.5,
        screenshots: app.screenshots || [
          'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8bW9iaWxlJTIwYXBwfGVufDB8fDB8fHww',
          'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fG1vYmlsZSUyMGFwcHxlbnwwfHwwfHx8MA%3D%3D',
          'https://images.unsplash.com/photo-1621839673705-6617adf9e890?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fG1vYmlsZSUyMGFwcHxlbnwwfHwwfHx8MA%3D%3D'
        ]
      }));
      
      setApps(enhancedData);
    } catch (error) {
      message.error('获取应用列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApps();
  }, [currentUser, isAdmin]);

  const handleDelete = async (id) => {
    try {
      await mockApi.deleteApp(id);
      message.success('删除成功');
      fetchApps();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const showAppDetail = (app) => {
    setCurrentApp(app);
    setDrawerVisible(true);
  };

  const handlePreviewImage = (image) => {
    setPreviewImage(image);
    setPreviewVisible(true);
  };

  const filteredApps = apps
    .filter(app => {
      const matchesSearch = (
        app.name.toLowerCase().includes(searchText.toLowerCase()) ||
        app.description.toLowerCase().includes(searchText.toLowerCase()) ||
        (app.packageName && app.packageName.toLowerCase().includes(searchText.toLowerCase()))
      );
      
      const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
      
      return matchesSearch && matchesStatus;
    });

  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      width: 60,
    },
    {
      title: '应用',
      key: 'app',
      render: (_, record) => (
        <Space>
          <Avatar src={record.logo} icon={<AppstoreOutlined />} shape="square" />
          <div>
            <div>{record.name}</div>
            <div style={{ fontSize: '12px', color: '#888' }}>{record.packageName}</div>
          </div>
        </Space>
      ),
    },
    {
      title: '版本',
      dataIndex: 'version',
      key: 'version',
      width: 100,
      render: (version, record) => (
        <div>
          <div>{version}</div>
          {record.isIteration && <Tag color="blue">迭代版本</Tag>}
        </div>
      ),
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true,
    },
    {
      title: '所有者',
      dataIndex: 'owner',
      key: 'owner',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: status => {
        let color = status === 'online' ? 'success' : 'default';
        let text = status === 'online' ? '在线' : '离线';
        
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 170,
    },
    {
      title: '操作',
      key: 'action',
      width: 200,
      render: (_, record) => (
        <Space size="small" className="table-actions">
          <Button 
            type="text" 
            size="small" 
            icon={<EyeOutlined />}
            onClick={() => showAppDetail(record)}
          />
          <Button 
            type="primary" 
            size="small" 
            icon={<EditOutlined />}
            onClick={() => navigate(`/apps/edit/${record.id}`)}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个应用吗？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button 
              danger 
              size="small" 
              icon={<DeleteOutlined />}
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  const renderCardView = () => {
    return (
      <Row gutter={[16, 16]}>
        {filteredApps.map(app => (
          <Col xs={24} sm={12} md={8} lg={6} key={app.id}>
            <Badge.Ribbon 
              text={app.isIteration ? "迭代版本" : ""}
              color="blue"
              style={{ display: app.isIteration ? 'block' : 'none' }}
            >
              <Card
                hoverable
                cover={
                  <div style={{ 
                    height: '180px', 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    background: '#f5f5f5',
                    position: 'relative',
                    overflow: 'hidden'
                  }}>
                    <img 
                      alt={app.name} 
                      src={app.logo} 
                      style={{ maxHeight: '120px', maxWidth: '120px' }} 
                    />
                    {app.screenshots && app.screenshots.length > 0 && (
                      <div 
                        style={{ 
                          position: 'absolute', 
                          bottom: '10px', 
                          right: '10px', 
                          background: 'rgba(0,0,0,0.5)', 
                          color: 'white',
                          padding: '2px 8px',
                          borderRadius: '10px',
                          fontSize: '12px',
                          cursor: 'pointer'
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          showAppDetail(app);
                        }}
                      >
                        <EyeOutlined /> {app.screenshots.length} 张截图
                      </div>
                    )}
                  </div>
                }
                actions={[
                  <Tooltip title="查看详情">
                    <EyeOutlined key="view" onClick={() => showAppDetail(app)} />
                  </Tooltip>,
                  <Tooltip title="编辑应用">
                    <EditOutlined key="edit" onClick={() => navigate(`/apps/edit/${app.id}`)} />
                  </Tooltip>,
                  <Popconfirm
                    title="确定要删除这个应用吗？"
                    onConfirm={() => handleDelete(app.id)}
                    okText="确定"
                    cancelText="取消"
                  >
                    <Tooltip title="删除应用">
                      <DeleteOutlined key="delete" />
                    </Tooltip>
                  </Popconfirm>,
                ]}
              >
                <Card.Meta
                  title={
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span>{app.name}</span>
                      <Tag color={app.status === 'online' ? 'success' : 'default'}>
                        {app.status === 'online' ? '在线' : '离线'}
                      </Tag>
                    </div>
                  }
                  description={
                    <>
                      <p style={{ margin: '5px 0', color: '#666', fontSize: '12px' }}>
                        {app.packageName}
                      </p>
                      <p style={{ margin: '5px 0', color: '#666', fontSize: '12px' }}>
                        版本: {app.version}
                      </p>
                      <p style={{ 
                        margin: '5px 0', 
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                        height: '40px'
                      }}>
                        {app.description}
                      </p>
                    </>
                  }
                />
              </Card>
            </Badge.Ribbon>
          </Col>
        ))}
      </Row>
    );
  };

  return (
    <div className="container">
      <div className="page-header">
        <h2>应用管理</h2>
        <Button 
          type="primary" 
          icon={<PlusOutlined />}
          onClick={() => navigate('/apps/add')}
        >
          新增应用
        </Button>
      </div>
      
      <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '10px' }}>
        <Space wrap>
          <Input
            placeholder="搜索应用名称、包名或描述"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            style={{ width: '300px' }}
            prefix={<SearchOutlined />}
            allowClear
          />
          <Select
            value={statusFilter}
            onChange={value => setStatusFilter(value)}
            style={{ width: '120px' }}
          >
            <Option value="all">全部状态</Option>
            <Option value="online">在线</Option>
            <Option value="offline">离线</Option>
          </Select>
        </Space>
        <Space>
          <Button 
            type={viewMode === 'table' ? 'primary' : 'default'}
            onClick={() => setViewMode('table')}
          >
            表格视图
          </Button>
          <Button 
            type={viewMode === 'card' ? 'primary' : 'default'}
            onClick={() => setViewMode('card')}
          >
            卡片视图
          </Button>
        </Space>
      </div>
      
      {viewMode === 'table' ? (
        <Table
          columns={columns}
          dataSource={filteredApps}
          rowKey="id"
          loading={loading}
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showTotal: (total) => `共 ${total} 条记录`,
          }}
        />
      ) : (
        renderCardView()
      )}
      
      {/* 应用详情抽屉 */}
      <Drawer
        title={currentApp ? currentApp.name : "应用详情"}
        width={720}
        placement="right"
        onClose={() => setDrawerVisible(false)}
        open={drawerVisible}
        extra={
          currentApp && (
            <Space>
              <Button onClick={() => navigate(`/apps/edit/${currentApp.id}`)} type="primary">
                编辑应用
              </Button>
            </Space>
          )
        }
      >
        {currentApp && (
          <div>
            <div style={{ display: 'flex', marginBottom: '24px' }}>
              <Avatar 
                src={currentApp.logo} 
                icon={<AppstoreOutlined />} 
                shape="square" 
                size={80}
                style={{ marginRight: '16px' }}
              />
              <div>
                <h3 style={{ marginBottom: '8px' }}>{currentApp.name}</h3>
                <p style={{ margin: '4px 0', color: '#666' }}>包名: {currentApp.packageName}</p>
                <p style={{ margin: '4px 0', color: '#666' }}>
                  版本: {currentApp.version} 
                  {currentApp.isIteration && <Tag color="blue" style={{ marginLeft: '8px' }}>迭代版本</Tag>}
                </p>
                <p style={{ margin: '4px 0' }}>
                  状态: <Tag color={currentApp.status === 'online' ? 'success' : 'default'}>
                    {currentApp.status === 'online' ? '在线' : '离线'}
                  </Tag>
                </p>
              </div>
            </div>
            
            <Card title="应用描述" style={{ marginBottom: '16px' }}>
              <p>{currentApp.description}</p>
            </Card>
            
            <Card 
              title="应用截图" 
              style={{ marginBottom: '16px' }}
              extra={<small>点击图片可查看大图</small>}
            >
              {currentApp.screenshots && currentApp.screenshots.length > 0 ? (
                <div style={{ display: 'flex', overflowX: 'auto', gap: '10px', padding: '10px 0' }}>
                  {currentApp.screenshots.map((screenshot, index) => (
                    <div 
                      key={index} 
                      style={{ 
                        minWidth: '200px', 
                        height: '380px', 
                        cursor: 'pointer',
                        border: '1px solid #eee',
                        borderRadius: '4px',
                        overflow: 'hidden'
                      }}
                      onClick={() => handlePreviewImage(screenshot)}
                    >
                      <img 
                        src={screenshot} 
                        alt={`应用截图 ${index + 1}`} 
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <p>暂无截图</p>
              )}
            </Card>
            
            <Card title="其他信息">
              <p>所有者: {currentApp.owner}</p>
              <p>创建时间: {currentApp.createTime}</p>
              <div style={{ marginTop: '16px' }}>
                <Button type="primary" icon={<DownloadOutlined />}>
                  下载安装包
                </Button>
              </div>
            </Card>
          </div>
        )}
      </Drawer>
      
      {/* 图片预览 */}
      {previewVisible && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 1001,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: 'rgba(0, 0, 0, 0.65)'
          }}
          onClick={() => setPreviewVisible(false)}
        >
          <img
            alt="预览图"
            style={{ maxWidth: '90%', maxHeight: '90%' }}
            src={previewImage}
          />
        </div>
      )}
    </div>
  );
};

export default AppList;
