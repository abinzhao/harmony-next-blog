import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Select, Switch, message, Spin, Space, Radio, Card, Tabs, Divider, Tag } from 'antd';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  FileTextOutlined, 
  CommentOutlined, 
  TagsOutlined, 
  CheckCircleOutlined, 
  HighlightOutlined 
} from '@ant-design/icons';
import MDEditor from '@uiw/react-md-editor';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;
const { TabPane } = Tabs;

// 编辑器主题
const editorThemes = [
  { key: 'default', name: '默认主题' },
  { key: 'vscode', name: 'VS Code' },
  { key: 'dark', name: '暗黑模式' },
  { key: 'github', name: 'GitHub' }
];

const ArticleEdit = () => {
  const [form] = Form.useForm();
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [content, setContent] = useState('');
  const [articleType, setArticleType] = useState('article'); // 'article' 或 'post'
  const [previewMode, setPreviewMode] = useState(false);
  const [editorTheme, setEditorTheme] = useState('default');
  const isEdit = !!id;

  useEffect(() => {
    if (isEdit) {
      fetchArticle();
    }
  }, [id]);

  const fetchArticle = async () => {
    try {
      setLoading(true);
      const article = await mockApi.getArticleById(id);
      
      form.setFieldsValue({
        title: article.title,
        type: article.type || 'article',
        tags: article.tags,
        status: article.status
      });
      
      setContent(article.content);
      setArticleType(article.type || 'article');
    } catch (error) {
      message.error('获取文章详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values) => {
    try {
      setSubmitting(true);
      
      const articleData = {
        ...values,
        content,
        type: articleType
      };
      
      if (isEdit) {
        await mockApi.updateArticle(id, articleData);
        message.success('更新成功');
      } else {
        await mockApi.createArticle(articleData, currentUser.id, currentUser.name);
        message.success('创建成功');
      }
      
      navigate('/articles');
    } catch (error) {
      message.error(isEdit ? '更新失败' : '创建失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTypeChange = (e) => {
    setArticleType(e.target.value);
  };

  const handleThemeChange = (value) => {
    setEditorTheme(value);
  };

  return (
    <div className="container">
      <div className="page-header">
        <h2>{isEdit ? `编辑${articleType === 'article' ? '文章' : '帖子'}` : `新增${articleType === 'article' ? '文章' : '帖子'}`}</h2>
      </div>
      
      <Spin spinning={loading}>
        <div className="form-container">
          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            initialValues={{
              status: 'published',
              tags: [],
              type: 'article'
            }}
          >
            <Card className="article-edit-card" bordered={false}>
              <Form.Item
                name="type"
                label="内容类型"
                rules={[{ required: true, message: '请选择内容类型' }]}
              >
                <Radio.Group onChange={handleTypeChange} value={articleType} buttonStyle="solid">
                  <Radio.Button value="article">
                    <FileTextOutlined /> 文章
                  </Radio.Button>
                  <Radio.Button value="post">
                    <CommentOutlined /> 帖子
                  </Radio.Button>
                </Radio.Group>
              </Form.Item>
              
              <Form.Item
                name="title"
                label={articleType === 'article' ? '文章标题' : '帖子标题'}
                rules={[{ required: true, message: '请输入标题' }]}
              >
                <Input 
                  prefix={<HighlightOutlined />} 
                  placeholder={`请输入${articleType === 'article' ? '文章' : '帖子'}标题`} 
                />
              </Form.Item>
            </Card>
            
            <Card 
              title="内容编辑" 
              className="article-edit-card" 
              bordered={false}
              extra={
                <Space>
                  <span>编辑器主题：</span>
                  <Select 
                    value={editorTheme} 
                    onChange={handleThemeChange}
                    style={{ width: 120 }}
                  >
                    {editorThemes.map(theme => (
                      <Option key={theme.key} value={theme.key}>{theme.name}</Option>
                    ))}
                  </Select>
                  <Button 
                    type={previewMode ? 'primary' : 'default'} 
                    onClick={() => setPreviewMode(!previewMode)}
                  >
                    {previewMode ? '返回编辑' : '预览'}
                  </Button>
                </Space>
              }
            >
              {previewMode ? (
                <div className="markdown-preview">
                  <div className="preview-title">预览</div>
                  <div className="preview-content">
                    <MDEditor.Markdown source={content} />
                  </div>
                </div>
              ) : (
                <Form.Item
                  required
                  rules={[{ required: true, message: '请输入内容' }]}
                >
                  <MDEditor
                    value={content}
                    onChange={setContent}
                    height={500}
                    preview="edit"
                    theme={editorTheme}
                  />
                </Form.Item>
              )}
            </Card>
            
            <Card 
              title={
                <span>
                  <TagsOutlined /> 标签与发布设置
                </span>
              } 
              className="article-edit-card" 
              bordered={false}
            >
              <Form.Item
                name="tags"
                label="标签"
              >
                <Select
                  mode="tags"
                  style={{ width: '100%' }}
                  placeholder="请输入标签，按回车确认"
                  options={[
                    { value: '开源', label: '开源' },
                    { value: '技术', label: '技术' },
                    { value: '前端', label: '前端' },
                    { value: '后端', label: '后端' },
                    { value: '人工智能', label: '人工智能' },
                    { value: '教程', label: '教程' },
                    { value: '讨论', label: '讨论' },
                    { value: '问答', label: '问答' },
                  ]}
                />
              </Form.Item>
              
              <Form.Item
                name="status"
                label="状态"
                rules={[{ required: true, message: '请选择状态' }]}
              >
                <Select placeholder="请选择状态">
                  <Option value="published">
                    <CheckCircleOutlined style={{ color: '#52c41a' }} /> 已发布
                  </Option>
                  <Option value="draft">
                    <span style={{ color: '#faad14' }}>草稿</span>
                  </Option>
                </Select>
              </Form.Item>
            </Card>
            
            <div className="form-actions">
              <Space>
                <Button type="primary" htmlType="submit" loading={submitting} size="large">
                  {isEdit ? '更新' : '发布'}
                </Button>
                <Button onClick={() => navigate('/articles')} size="large">
                  取消
                </Button>
              </Space>
            </div>
          </Form>
        </div>
      </Spin>
    </div>
  );
};

export default ArticleEdit;
