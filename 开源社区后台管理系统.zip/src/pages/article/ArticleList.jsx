import React, { useState, useEffect } from 'react';
import { Table, Button, Space, Popconfirm, Tag, message, Input, Select, Tabs, Card, Radio } from 'antd';
import { 
  PlusOutlined, 
  DeleteOutlined, 
  EditOutlined, 
  SearchOutlined, 
  FileTextOutlined, 
  CommentOutlined, 
  EyeOutlined 
} from '@ant-design/icons';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;
const { TabPane } = Tabs;

const ArticleList = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const { currentUser, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const defaultType = searchParams.get('type') || 'all';

  useEffect(() => {
    setTypeFilter(defaultType);
  }, [defaultType]);

  const fetchArticles = async () => {
    try {
      setLoading(true);
      // 管理员获取所有文章，普通用户只获取自己的文章
      const data = await mockApi.getArticles(isAdmin ? null : currentUser.id);
      
      // 为了演示，给一些文章添加类型属性
      const enhancedData = data.map(article => ({
        ...article,
        type: article.type || (Math.random() > 0.5 ? 'article' : 'post')
      }));
      
      setArticles(enhancedData);
    } catch (error) {
      message.error('获取文章列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchArticles();
  }, [currentUser, isAdmin]);

  const handleDelete = async (id) => {
    try {
      await mockApi.deleteArticle(id);
      message.success('删除成功');
      fetchArticles();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const filteredArticles = articles
    .filter(article => {
      const matchesSearch = article.title.toLowerCase().includes(searchText.toLowerCase()) ||
                           article.content.toLowerCase().includes(searchText.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || article.status === statusFilter;
      
      const matchesType = typeFilter === 'all' || article.type === typeFilter;
      
      return matchesSearch && matchesStatus && matchesType;
    });

  const handleAddNew = () => {
    if (typeFilter === 'post') {
      navigate('/articles/add', { state: { type: 'post' } });
    } else {
      navigate('/articles/add');
    }
  };

  const handleTypeChange = (e) => {
    const type = e.target.value;
    setTypeFilter(type);
    
    // 更新URL查询参数但不重新加载页面
    if (type === 'all') {
      navigate('/articles');
    } else {
      navigate(`/articles?type=${type}`);
    }
  };

  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      width: 60,
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      width: 80,
      render: type => {
        const isArticle = type === 'article';
        return (
          <Tag 
            icon={isArticle ? <FileTextOutlined /> : <CommentOutlined />}
            color={isArticle ? 'blue' : 'green'}
          >
            {isArticle ? '文章' : '帖子'}
          </Tag>
        );
      }
    },
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      render: (text, record) => (
        <Link to={`/articles/edit/${record.id}`}>{text}</Link>
      ),
    },
    {
      title: '作者',
      dataIndex: 'author',
      key: 'author',
      width: 120,
    },
    {
      title: '标签',
      dataIndex: 'tags',
      key: 'tags',
      width: 200,
      render: tags => (
        <>
          {tags && tags.map(tag => (
            <Tag color="blue" key={tag}>
              {tag}
            </Tag>
          ))}
        </>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: status => {
        let color = 'default';
        let text = '未知';
        
        if (status === 'published') {
          color = 'success';
          text = '已发布';
        } else if (status === 'draft') {
          color = 'warning';
          text = '草稿';
        }
        
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 180,
    },
    {
      title: '操作',
      key: 'action',
      width: 180,
      render: (_, record) => (
        <Space size="small" className="table-actions">
          <Button 
            type="text" 
            size="small" 
            icon={<EyeOutlined />}
            onClick={() => navigate(`/articles/view/${record.id}`)}
            title="查看"
          />
          <Button 
            type="primary" 
            size="small" 
            icon={<EditOutlined />}
            onClick={() => navigate(`/articles/edit/${record.id}`)}
          >
            编辑
          </Button>
          <Popconfirm
            title={`确定要删除这篇${record.type === 'article' ? '文章' : '帖子'}吗？`}
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button 
              danger 
              size="small" 
              icon={<DeleteOutlined />}
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="container">
      <div className="page-header">
        <h2>{typeFilter === 'post' ? '帖子管理' : typeFilter === 'article' ? '文章管理' : '内容管理'}</h2>
        <Button 
          type="primary" 
          icon={<PlusOutlined />}
          onClick={handleAddNew}
        >
          {typeFilter === 'post' ? '发布帖子' : typeFilter === 'article' ? '新增文章' : '新增内容'}
        </Button>
      </div>
      
      <Card bordered={false} style={{ marginBottom: '20px' }}>
        <div style={{ marginBottom: '20px' }}>
          <Radio.Group 
            value={typeFilter} 
            onChange={handleTypeChange}
            optionType="button" 
            buttonStyle="solid"
            style={{ marginBottom: '16px' }}
          >
            <Radio.Button value="all">全部内容</Radio.Button>
            <Radio.Button value="article">
              <FileTextOutlined /> 文章
            </Radio.Button>
            <Radio.Button value="post">
              <CommentOutlined /> 帖子
            </Radio.Button>
          </Radio.Group>
        </div>
        
        <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
          <Input
            placeholder="搜索标题或内容"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            style={{ width: '300px' }}
            prefix={<SearchOutlined />}
            allowClear
          />
          <Select
            style={{ width: '150px' }}
            value={statusFilter}
            onChange={value => setStatusFilter(value)}
          >
            <Option value="all">全部状态</Option>
            <Option value="published">已发布</Option>
            <Option value="draft">草稿</Option>
          </Select>
        </div>
      </Card>
      
      <Table
        columns={columns}
        dataSource={filteredArticles}
        rowKey="id"
        loading={loading}
        pagination={{
          pageSize: 10,
          showSizeChanger: true,
          showTotal: (total) => `共 ${total} 条记录`,
        }}
      />
    </div>
  );
};

export default ArticleList;
