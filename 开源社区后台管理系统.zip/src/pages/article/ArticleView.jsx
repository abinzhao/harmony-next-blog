import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, Tag, Space, Breadcrumb, message, BackTop, Avatar, Divider, Tooltip, Typography } from 'antd';
import MDEditor from '@uiw/react-md-editor';
import { 
  EditOutlined,
  ArrowLeftOutlined,
  UserOutlined,
  ClockCircleOutlined,
  TagOutlined,
  EyeOutlined,
  HeartOutlined,
  HeartFilled,
  ShareAltOutlined,
  FileTextOutlined,
  CommentOutlined
} from '@ant-design/icons';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';
import './ArticleView.css';

const { Text, Title } = Typography;

const ArticleView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [viewCount, setViewCount] = useState(0);
  const [comments, setComments] = useState([]);
  const [commentValue, setCommentValue] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchArticle();
  }, [id]);

  const fetchArticle = async () => {
    try {
      setLoading(true);
      const data = await mockApi.getArticleById(id);
      setArticle(data);
      
      // 模拟数据
      setLikeCount(Math.floor(Math.random() * 100));
      setViewCount(Math.floor(Math.random() * 1000));
      
      // 获取评论
      if (data.comments) {
        setComments(data.comments);
      }
    } catch (error) {
      message.error('获取文章详情失败');
      navigate('/articles');
    } finally {
      setLoading(false);
    }
  };

  const handleLike = () => {
    setLiked(!liked);
    setLikeCount(prev => liked ? prev - 1 : prev + 1);
    message.success(liked ? '已取消点赞' : '点赞成功');
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    message.success('链接已复制到剪贴板');
  };

  const handleCommentSubmit = async () => {
    if (!commentValue.trim()) {
      return;
    }

    try {
      setSubmitting(true);
      await mockApi.addComment(
        article.type,
        id,
        commentValue,
        currentUser.id,
        currentUser.name
      );
      setCommentValue('');
      message.success('评论发布成功');
      // 刷新评论
      fetchArticle();
    } catch (error) {
      message.error('评论发布失败');
    } finally {
      setSubmitting(false);
    }
  };

  if (!article && !loading) {
    return null;
  }

  const getTypeIcon = (type) => {
    return type === 'article' ? <FileTextOutlined /> : <CommentOutlined />;
  };

  const getTypeText = (type) => {
    return type === 'article' ? '文章' : '帖子';
  };

  return (
    <div className="container article-view-container">
      <BackTop />
      
      <Breadcrumb style={{ marginBottom: '16px' }}>
        <Breadcrumb.Item><a href="#/">首页</a></Breadcrumb.Item>
        <Breadcrumb.Item><a href="#/articles">内容管理</a></Breadcrumb.Item>
        <Breadcrumb.Item>{article?.type === 'article' ? '文章详情' : '帖子详情'}</Breadcrumb.Item>
      </Breadcrumb>
      
      <div className="page-header" style={{ marginBottom: '24px' }}>
        <Button 
          icon={<ArrowLeftOutlined />} 
          onClick={() => navigate('/articles')}
        >
          返回列表
        </Button>
        
        {currentUser && (currentUser.id === article?.authorId || currentUser.role === 'admin') && (
          <Button 
            type="primary" 
            icon={<EditOutlined />} 
            onClick={() => navigate(`/articles/edit/${id}`)}
          >
            编辑{article?.type === 'article' ? '文章' : '帖子'}
          </Button>
        )}
      </div>
      
      {article && (
        <div className="article-content-wrapper">
          <Card 
            bordered={false} 
            loading={loading}
            className="article-card"
          >
            <div className="article-header">
              <div className="article-type-tag">
                <Tag color={article.type === 'article' ? 'blue' : 'green'}>
                  {getTypeIcon(article.type)} {getTypeText(article.type)}
                </Tag>
              </div>
              
              <Title level={1} className="article-title">
                {article.title}
              </Title>
              
              <div className="article-meta">
                <Space size={16} wrap>
                  <div className="article-author">
                    <Avatar size="small" src={article.authorAvatar} icon={<UserOutlined />} />
                    <span>{article.author}</span>
                  </div>
                  <div className="article-time">
                    <ClockCircleOutlined style={{ marginRight: '4px' }} />
                    <span>{article.createTime}</span>
                  </div>
                  <div className="article-views">
                    <EyeOutlined style={{ marginRight: '4px' }} />
                    <span>{viewCount} 阅读</span>
                  </div>
                  <div className="article-tags">
                    <TagOutlined style={{ marginRight: '4px' }} />
                    {article.tags && article.tags.map(tag => (
                      <Tag key={tag} color="blue">{tag}</Tag>
                    ))}
                  </div>
                </Space>
              </div>
            </div>
            
            <Divider style={{ margin: '20px 0' }} />
            
            <div className="article-content">
              <MDEditor.Markdown source={article.content} />
            </div>
            
            <div className="article-footer">
              <div className="article-actions">
                <Space size="large">
                  <Tooltip title={liked ? '取消点赞' : '点赞'}>
                    <Button 
                      type={liked ? 'primary' : 'default'} 
                      shape="round" 
                      icon={liked ? <HeartFilled /> : <HeartOutlined />}
                      onClick={handleLike}
                    >
                      {likeCount} 点赞
                    </Button>
                  </Tooltip>
                  <Tooltip title="分享">
                    <Button 
                      shape="round" 
                      icon={<ShareAltOutlined />}
                      onClick={handleShare}
                    >
                      分享
                    </Button>
                  </Tooltip>
                </Space>
              </div>
            </div>
          </Card>
          
          {/* 评论区 */}
          <Card 
            title={
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <CommentOutlined style={{ marginRight: '8px' }} />
                <span>评论区 ({comments.length})</span>
              </div>
            } 
            bordered={false}
            className="comment-card"
          >
            {comments.length > 0 ? (
              <div className="comment-list">
                {comments.map((comment, index) => (
                  <div key={comment.id || index} className="comment-item">
                    <div className="comment-avatar">
                      <Avatar icon={<UserOutlined />} src={comment.avatar}>
                        {!comment.avatar && comment.author.substring(0, 1)}
                      </Avatar>
                    </div>
                    <div className="comment-content">
                      <div className="comment-author">{comment.author}</div>
                      <div className="comment-text">{comment.content}</div>
                      <div className="comment-time">{comment.createTime}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="comment-empty">暂无评论，快来发表第一条评论吧！</div>
            )}
            
            <Divider />
            
            {currentUser ? (
              <div className="comment-form">
                <div className="comment-form-header">
                  <Avatar icon={<UserOutlined />} src={currentUser.avatar}>
                    {!currentUser.avatar && currentUser.name.substring(0, 1)}
                  </Avatar>
                  <span className="comment-form-name">{currentUser.name}</span>
                </div>
                <div className="comment-textarea">
                  <textarea 
                    placeholder="写下你的评论..." 
                    value={commentValue}
                    onChange={e => setCommentValue(e.target.value)}
                  />
                </div>
                <div className="comment-form-footer">
                  <Button 
                    type="primary" 
                    onClick={handleCommentSubmit}
                    loading={submitting}
                    disabled={!commentValue.trim()}
                  >
                    发表评论
                  </Button>
                </div>
              </div>
            ) : (
              <div className="comment-login-tip">
                请<a href="#/login">登录</a>后发表评论
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
};

export default ArticleView;
