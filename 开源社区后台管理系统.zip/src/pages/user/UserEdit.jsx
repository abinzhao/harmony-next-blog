import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Select, Switch, message, Spin, Space, Upload, Avatar } from 'antd';
import { UserOutlined, MailOutlined, UploadOutlined, LockOutlined } from '@ant-design/icons';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const { Option } = Select;

const UserEdit = () => {
  const [form] = Form.useForm();
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const isEdit = !!id;

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      message.error('您没有权限访问此页面');
      return;
    }
    
    if (isEdit) {
      fetchUser();
    }
  }, [id, isAdmin]);

  const fetchUser = async () => {
    try {
      setLoading(true);
      const user = await mockApi.getUserById(id);
      
      form.setFieldsValue({
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status === 'active'
      });
    } catch (error) {
      message.error('获取用户详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values) => {
    try {
      setSubmitting(true);
      
      const userData = {
        ...values,
        status: values.status ? 'active' : 'inactive'
      };
      
      if (isEdit) {
        await mockApi.updateUser(id, userData);
        message.success('更新成功');
      } else {
        await mockApi.createUser(userData);
        message.success('创建成功');
      }
      
      navigate('/users');
    } catch (error) {
      message.error(isEdit ? '更新失败' : '创建失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container">
      <div className="page-header">
        <h2>{isEdit ? '编辑用户' : '新增用户'}</h2>
      </div>
      
      <Spin spinning={loading}>
        <div className="form-container">
          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            initialValues={{
              role: 'user',
              status: true
            }}
          >
            <Form.Item
              name="username"
              label="用户名"
              rules={[
                { required: true, message: '请输入用户名' },
                { min: 3, message: '用户名至少3个字符' }
              ]}
            >
              <Input 
                prefix={<UserOutlined />} 
                placeholder="请输入用户名" 
                disabled={isEdit} // 编辑模式下不允许修改用户名
              />
            </Form.Item>
            
            <Form.Item
              name="name"
              label="姓名"
              rules={[{ required: true, message: '请输入姓名' }]}
            >
              <Input prefix={<UserOutlined />} placeholder="请输入姓名" />
            </Form.Item>
            
            <Form.Item
              name="email"
              label="邮箱"
              rules={[
                { required: true, message: '请输入邮箱' },
                { type: 'email', message: '请输入有效的邮箱地址' }
              ]}
            >
              <Input prefix={<MailOutlined />} placeholder="请输入邮箱" />
            </Form.Item>
            
            {!isEdit && (
              <Form.Item
                name="password"
                label="密码"
                rules={[
                  { required: true, message: '请输入密码' },
                  { min: 6, message: '密码至少6个字符' }
                ]}
              >
                <Input.Password prefix={<LockOutlined />} placeholder="请输入密码" />
              </Form.Item>
            )}
            
            <Form.Item
              name="role"
              label="角色"
              rules={[{ required: true, message: '请选择角色' }]}
            >
              <Select placeholder="请选择角色">
                <Option value="admin">管理员</Option>
                <Option value="user">普通用户</Option>
              </Select>
            </Form.Item>
            
            <Form.Item
              name="status"
              label="状态"
              valuePropName="checked"
            >
              <Switch checkedChildren="启用" unCheckedChildren="禁用" />
            </Form.Item>
            
            <Form.Item>
              <Space>
                <Button type="primary" htmlType="submit" loading={submitting}>
                  {isEdit ? '更新用户' : '创建用户'}
                </Button>
                <Button onClick={() => navigate('/users')}>
                  取消
                </Button>
              </Space>
            </Form.Item>
          </Form>
        </div>
      </Spin>
    </div>
  );
};

export default UserEdit;
