import React, { useState, useEffect } from 'react';
import { Table, Button, Space, Popconfirm, Tag, message, Input, Avatar } from 'antd';
import { PlusOutlined, DeleteOutlined, EditOutlined, SearchOutlined, UserOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { mockApi } from '../../utils/mockData';

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const { currentUser, isAdmin } = useAuth();
  const navigate = useNavigate();

  const fetchUsers = async () => {
    try {
      setLoading(true);
      if (isAdmin) {
        const data = await mockApi.getUsers();
        setUsers(data);
      } else {
        // 非管理员不应该访问此页面，重定向到首页
        navigate('/');
        message.error('您没有权限访问此页面');
      }
    } catch (error) {
      message.error('获取用户列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [isAdmin]);

  const handleDelete = async (id) => {
    // 不允许删除自己
    if (id === currentUser.id) {
      message.error('不能删除自己的账号');
      return;
    }
    
    try {
      await mockApi.deleteUser(id);
      message.success('删除成功');
      fetchUsers();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const filteredUsers = users
    .filter(user => {
      return (
        user.username.toLowerCase().includes(searchText.toLowerCase()) ||
        user.name.toLowerCase().includes(searchText.toLowerCase()) ||
        user.email.toLowerCase().includes(searchText.toLowerCase())
      );
    });

  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      width: 60,
    },
    {
      title: '用户',
      key: 'user',
      render: (_, record) => (
        <Space>
          <Avatar src={record.avatar} icon={<UserOutlined />} />
          <span>{record.name}</span>
        </Space>
      ),
    },
    {
      title: '用户名',
      dataIndex: 'username',
      key: 'username',
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: '角色',
      dataIndex: 'role',
      key: 'role',
      render: role => {
        let color = role === 'admin' ? 'red' : 'green';
        let text = role === 'admin' ? '管理员' : '普通用户';
        
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: status => {
        let color = status === 'active' ? 'success' : 'default';
        let text = status === 'active' ? '正常' : '禁用';
        
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: '注册时间',
      dataIndex: 'createTime',
      key: 'createTime',
    },
    {
      title: '操作',
      key: 'action',
      width: 150,
      render: (_, record) => (
        <Space size="small" className="table-actions">
          <Button 
            type="primary" 
            size="small" 
            icon={<EditOutlined />}
            onClick={() => navigate(`/users/edit/${record.id}`)}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个用户吗？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
            disabled={record.id === currentUser.id}
          >
            <Button 
              danger 
              size="small" 
              icon={<DeleteOutlined />}
              disabled={record.id === currentUser.id}
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  if (!isAdmin) {
    return null; // 非管理员不显示内容
  }

  return (
    <div className="container">
      <div className="page-header">
        <h2>用户管理</h2>
        <Button 
          type="primary" 
          icon={<PlusOutlined />}
          onClick={() => navigate('/users/add')}
        >
          新增用户
        </Button>
      </div>
      
      <div style={{ marginBottom: '20px' }}>
        <Input
          placeholder="搜索用户名、姓名或邮箱"
          value={searchText}
          onChange={e => setSearchText(e.target.value)}
          style={{ width: '300px' }}
          prefix={<SearchOutlined />}
          allowClear
        />
      </div>
      
      <Table
        columns={columns}
        dataSource={filteredUsers}
        rowKey="id"
        loading={loading}
        pagination={{
          pageSize: 10,
          showSizeChanger: true,
          showTotal: (total) => `共 ${total} 条记录`,
        }}
      />
    </div>
  );
};

export default UserList;
