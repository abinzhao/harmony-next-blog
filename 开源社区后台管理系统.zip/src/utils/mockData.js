// 模拟数据存储
let articles = [
  {
    id: 1,
    title: '开源社区发展历程',
    content: '<p>开源社区是指围绕开源软件项目而形成的一个社会性组织，由开发者、用户和其他贡献者组成。这些社区成员共同协作，不断改进和发展开源软件项目。</p>',
    author: '管理员',
    authorId: 1,
    createTime: '2023-08-20 10:00:00',
    updateTime: '2023-08-20 10:00:00',
    tags: ['开源', '社区'],
    status: 'published',
    type: 'article'
  },
  {
    id: 2,
    title: 'React 18 新特性解析',
    content: '<p>React 18 带来了许多新特性，包括自动批处理、新的 Suspense SSR 架构、并发渲染等。这些特性将帮助开发者构建更好的用户体验。</p>',
    author: '管理员',
    authorId: 1,
    createTime: '2023-08-19 15:30:00',
    updateTime: '2023-08-19 15:30:00',
    tags: ['React', '前端'],
    status: 'published',
    type: 'article'
  },
  {
    id: 3,
    title: '如何参与开源项目',
    content: '<p>参与开源项目是提升编程技能的绝佳方式。本文将介绍如何找到适合自己的开源项目，以及如何有效地贡献代码。</p>',
    author: '普通用户',
    authorId: 2,
    createTime: '2023-08-18 09:15:00',
    updateTime: '2023-08-18 09:15:00',
    tags: ['开源', '贡献'],
    status: 'published',
    type: 'article'
  },
  {
    id: 4,
    title: '有人遇到过这个问题吗？Node.js安装失败',
    content: '# 求助\n\n我在Windows 11上安装Node.js时遇到了问题，安装到一半就报错了。错误信息如下：\n\n```\nError: EPERM: operation not permitted\n```\n\n有谁知道怎么解决吗？',
    author: '普通用户',
    authorId: 2,
    createTime: '2023-08-17 14:20:00',
    updateTime: '2023-08-17 14:20:00',
    tags: ['问题', 'Node.js'],
    status: 'published',
    type: 'post'
  },
  {
    id: 5,
    title: '分享一个好用的VS Code插件',
    content: '今天发现了一个非常好用的VS Code插件：GitLens。它可以让你在编辑器中直接看到每一行代码的提交历史，谁修改的，什么时候修改的，都一目了然。\n\n强烈推荐给大家！',
    author: '管理员',
    authorId: 1,
    createTime: '2023-08-16 11:05:00',
    updateTime: '2023-08-16 11:05:00',
    tags: ['工具', 'VS Code'],
    status: 'published',
    type: 'post'
  }
];

let users = [
  {
    id: 1,
    username: 'admin',
    name: '管理员',
    email: 'admin@example.com',
    role: 'admin',
    status: 'active',
    createTime: '2023-08-01 00:00:00',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
  },
  {
    id: 2,
    username: 'user',
    name: '普通用户',
    email: 'user@example.com',
    role: 'user',
    status: 'active',
    createTime: '2023-08-02 00:00:00',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
  }
];

let apps = [
  {
    id: 1,
    name: '社区论坛',
    description: '一个用于讨论开源技术的论坛应用',
    owner: '管理员',
    ownerId: 1,
    createTime: '2023-08-10 10:00:00',
    status: 'online',
    logo: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80'
  },
  {
    id: 2,
    name: '代码托管',
    description: '提供代码托管和版本控制服务',
    owner: '管理员',
    ownerId: 1,
    createTime: '2023-08-11 14:30:00',
    status: 'online',
    logo: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80'
  },
  {
    id: 3,
    name: '技术博客',
    description: '分享技术文章和教程的博客平台',
    owner: '普通用户',
    ownerId: 2,
    createTime: '2023-08-12 09:15:00',
    status: 'online',
    logo: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80'
  }
];

let announcements = [
  {
    id: 1,
    title: '系统维护通知',
    content: '# 系统维护通知\n\n尊敬的用户，我们将于2023年8月25日凌晨2:00-4:00进行系统维护，期间系统可能无法访问。给您带来的不便，敬请谅解。\n\n## 维护内容\n\n- 服务器硬件升级\n- 数据库性能优化\n- 安全补丁更新\n\n维护完成后，系统将会变得更加稳定、安全，感谢您的理解和支持！',
    author: '管理员',
    authorId: 1,
    createTime: '2023-08-20 10:00:00',
    updateTime: '2023-08-20 10:00:00',
    status: 'published',
    priority: 'high',
    comments: [
      {
        id: 1,
        content: '好的，了解了，谢谢通知！',
        author: '普通用户',
        authorId: 2,
        createTime: '2023-08-20 10:30:00'
      }
    ]
  },
  {
    id: 2,
    title: '新功能上线公告',
    content: '# 新功能上线公告\n\n我们很高兴地通知您，文章管理模块新增了标签功能，现在您可以通过标签更好地组织您的文章。\n\n## 主要更新\n\n1. 文章可添加多个标签\n2. 支持按标签筛选文章\n3. 优化了文章编辑界面\n\n如有任何问题或建议，请随时联系我们！',
    author: '管理员',
    authorId: 1,
    createTime: '2023-08-18 15:30:00',
    updateTime: '2023-08-18 15:30:00',
    status: 'published',
    priority: 'medium',
    comments: []
  },
  {
    id: 3,
    title: '用户体验调查',
    content: '# 用户体验调查\n\n为了不断改进我们的产品，我们诚邀您参与此次用户体验调查。您的反馈对我们非常重要。\n\n## 调查内容\n\n调查主要涉及以下方面：\n\n- 界面易用性\n- 功能完整性\n- 系统响应速度\n- 您希望添加的新功能\n\n完成调查仅需3-5分钟，感谢您的参与！',
    author: '管理员',
    authorId: 1,
    createTime: '2023-08-15 09:00:00',
    updateTime: '2023-08-15 09:00:00',
    status: 'published',
    priority: 'low',
    comments: [
      {
        id: 2,
        content: '已填写完成，希望能有更多的自定义功能！',
        author: '普通用户',
        authorId: 2,
        createTime: '2023-08-15 10:20:00'
      }
    ]
  }
];

// 模拟 API 服务
export const mockApi = {
  // 文章相关 API
  getArticles: (userId = null) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        // 如果提供了userId，只返回该用户的文章
        const filteredArticles = userId 
          ? articles.filter(article => article.authorId === userId)
          : articles;
        resolve(filteredArticles);
      }, 300);
    });
  },
  
  getArticleById: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const article = articles.find(a => a.id === parseInt(id));
        if (article) {
          resolve(article);
        } else {
          reject(new Error('文章不存在'));
        }
      }, 300);
    });
  },
  
  createArticle: (article, userId, userName) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newArticle = {
          ...article,
          id: articles.length > 0 ? Math.max(...articles.map(a => a.id)) + 1 : 1,
          authorId: userId,
          author: userName,
          createTime: new Date().toLocaleString(),
          updateTime: new Date().toLocaleString(),
          type: article.type || 'article'
        };
        articles.push(newArticle);
        resolve(newArticle);
      }, 300);
    });
  },
  
  updateArticle: (id, article) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = articles.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
          articles[index] = {
            ...articles[index],
            ...article,
            updateTime: new Date().toLocaleString()
          };
          resolve(articles[index]);
        } else {
          reject(new Error('文章不存在'));
        }
      }, 300);
    });
  },
  
  deleteArticle: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = articles.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
          articles.splice(index, 1);
          resolve({ success: true });
        } else {
          reject(new Error('文章不存在'));
        }
      }, 300);
    });
  },

  // 用户相关 API
  getUsers: () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(users);
      }, 300);
    });
  },
  
  getUserById: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const user = users.find(u => u.id === parseInt(id));
        if (user) {
          resolve(user);
        } else {
          reject(new Error('用户不存在'));
        }
      }, 300);
    });
  },
  
  createUser: (user) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newUser = {
          ...user,
          id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
          createTime: new Date().toLocaleString(),
          status: 'active'
        };
        users.push(newUser);
        resolve(newUser);
      }, 300);
    });
  },
  
  updateUser: (id, user) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = users.findIndex(u => u.id === parseInt(id));
        if (index !== -1) {
          users[index] = {
            ...users[index],
            ...user
          };
          resolve(users[index]);
        } else {
          reject(new Error('用户不存在'));
        }
      }, 300);
    });
  },
  
  deleteUser: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = users.findIndex(u => u.id === parseInt(id));
        if (index !== -1) {
          users.splice(index, 1);
          resolve({ success: true });
        } else {
          reject(new Error('用户不存在'));
        }
      }, 300);
    });
  },

  // 应用相关 API
  getApps: (userId = null) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        // 如果提供了userId，只返回该用户的应用
        const filteredApps = userId 
          ? apps.filter(app => app.ownerId === userId)
          : apps;
        resolve(filteredApps);
      }, 300);
    });
  },
  
  getAppById: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const app = apps.find(a => a.id === parseInt(id));
        if (app) {
          resolve(app);
        } else {
          reject(new Error('应用不存在'));
        }
      }, 300);
    });
  },
  
  createApp: (app, userId, userName) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newApp = {
          ...app,
          id: apps.length > 0 ? Math.max(...apps.map(a => a.id)) + 1 : 1,
          ownerId: userId,
          owner: userName,
          createTime: new Date().toLocaleString(),
          status: app.status || 'online',
          packageName: app.packageName || `com.example.${app.name.toLowerCase().replace(/\s/g, '')}`,
          version: app.version || '1.0.0',
          isIteration: app.isIteration || false,
          screenshots: app.screenshots || []
        };
        apps.push(newApp);
        resolve(newApp);
      }, 300);
    });
  },
  
  updateApp: (id, app) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = apps.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
          apps[index] = {
            ...apps[index],
            ...app
          };
          resolve(apps[index]);
        } else {
          reject(new Error('应用不存在'));
        }
      }, 300);
    });
  },
  
  deleteApp: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = apps.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
          apps.splice(index, 1);
          resolve({ success: true });
        } else {
          reject(new Error('应用不存在'));
        }
      }, 300);
    });
  },

  // 公告相关 API
  getAnnouncements: () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(announcements);
      }, 300);
    });
  },
  
  getAnnouncementById: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const announcement = announcements.find(a => a.id === parseInt(id));
        if (announcement) {
          resolve(announcement);
        } else {
          reject(new Error('公告不存在'));
        }
      }, 300);
    });
  },
  
  createAnnouncement: (announcement, userId, userName) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const newAnnouncement = {
          ...announcement,
          id: announcements.length > 0 ? Math.max(...announcements.map(a => a.id)) + 1 : 1,
          authorId: userId,
          author: userName,
          createTime: new Date().toLocaleString(),
          updateTime: new Date().toLocaleString(),
          comments: []
        };
        announcements.push(newAnnouncement);
        resolve(newAnnouncement);
      }, 300);
    });
  },
  
  updateAnnouncement: (id, announcement) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = announcements.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
          announcements[index] = {
            ...announcements[index],
            ...announcement,
            updateTime: new Date().toLocaleString()
          };
          resolve(announcements[index]);
        } else {
          reject(new Error('公告不存在'));
        }
      }, 300);
    });
  },
  
  // 添加评论相关API
  addComment: (targetType, targetId, comment, userId, userName) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const newComment = {
          id: Date.now(),
          content: comment,
          authorId: userId,
          author: userName,
          createTime: new Date().toLocaleString()
        };
        
        // 根据目标类型添加评论
        if (targetType === 'announcement') {
          const announcement = announcements.find(a => a.id === parseInt(targetId));
          if (announcement) {
            if (!announcement.comments) {
              announcement.comments = [];
            }
            announcement.comments.push(newComment);
            resolve(newComment);
          } else {
            reject(new Error('公告不存在'));
          }
        } else if (targetType === 'article') {
          const article = articles.find(a => a.id === parseInt(targetId));
          if (article) {
            if (!article.comments) {
              article.comments = [];
            }
            article.comments.push(newComment);
            resolve(newComment);
          } else {
            reject(new Error('文章不存在'));
          }
        } else if (targetType === 'app') {
          const app = apps.find(a => a.id === parseInt(targetId));
          if (app) {
            if (!app.comments) {
              app.comments = [];
            }
            app.comments.push(newComment);
            resolve(newComment);
          } else {
            reject(new Error('应用不存在'));
          }
        } else {
          reject(new Error('无效的目标类型'));
        }
      }, 300);
    });
  },
  
  getComments: (targetType, targetId) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // 根据目标类型获取评论
        if (targetType === 'announcement') {
          const announcement = announcements.find(a => a.id === parseInt(targetId));
          if (announcement) {
            resolve(announcement.comments || []);
          } else {
            reject(new Error('公告不存在'));
          }
        } else if (targetType === 'article') {
          const article = articles.find(a => a.id === parseInt(targetId));
          if (article) {
            resolve(article.comments || []);
          } else {
            reject(new Error('文章不存在'));
          }
        } else if (targetType === 'app') {
          const app = apps.find(a => a.id === parseInt(targetId));
          if (app) {
            resolve(app.comments || []);
          } else {
            reject(new Error('应用不存在'));
          }
        } else {
          reject(new Error('无效的目标类型'));
        }
      }, 300);
    });
  },
  
  deleteComment: (targetType, targetId, commentId) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // 根据目标类型删除评论
        if (targetType === 'announcement') {
          const announcement = announcements.find(a => a.id === parseInt(targetId));
          if (announcement && announcement.comments) {
            const index = announcement.comments.findIndex(c => c.id === commentId);
            if (index !== -1) {
              announcement.comments.splice(index, 1);
              resolve({ success: true });
            } else {
              reject(new Error('评论不存在'));
            }
          } else {
            reject(new Error('公告不存在或无评论'));
          }
        } else if (targetType === 'article') {
          const article = articles.find(a => a.id === parseInt(targetId));
          if (article && article.comments) {
            const index = article.comments.findIndex(c => c.id === commentId);
            if (index !== -1) {
              article.comments.splice(index, 1);
              resolve({ success: true });
            } else {
              reject(new Error('评论不存在'));
            }
          } else {
            reject(new Error('文章不存在或无评论'));
          }
        } else if (targetType === 'app') {
          const app = apps.find(a => a.id === parseInt(targetId));
          if (app && app.comments) {
            const index = app.comments.findIndex(c => c.id === commentId);
            if (index !== -1) {
              app.comments.splice(index, 1);
              resolve({ success: true });
            } else {
              reject(new Error('评论不存在'));
            }
          } else {
            reject(new Error('应用不存在或无评论'));
          }
        } else {
          reject(new Error('无效的目标类型'));
        }
      }, 300);
    });
  },
  
  deleteAnnouncement: (id) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const index = announcements.findIndex(a => a.id === parseInt(id));
        if (index !== -1) {
          announcements.splice(index, 1);
          resolve({ success: true });
        } else {
          reject(new Error('公告不存在'));
        }
      }, 300);
    });
  }
};
